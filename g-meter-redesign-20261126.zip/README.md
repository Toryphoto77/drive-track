# G 表盘改版 · 文件包说明

日期：2026-11-26

## 包含文件

```
lib/recorder.dart   # 新增四向峰值字段与统计（必须一起覆盖）
lib/widgets.dart    # G 表盘重写（GCirlce / GCirlcePainter）
lib/main.dart       # 记录页与 G 值详情页接入 + 详情页图例
```

> 三个文件必须**同时**覆盖。`main.dart` 引用 `recorder.dart` 新增的
> `tripMaxAccelG / tripMaxBrakeG / tripMaxRightG / tripMaxLeftG`，
> 只覆盖其中一部分会编译失败。

## 覆盖方式

1. 先备份本地原文件（或确认 git 工作区干净）。
2. 把压缩包里的 `lib/` 目录整个覆盖到工程根目录（与现有 `lib/` 合并）。
3. 执行：

```bash
flutter analyze lib/widgets.dart lib/main.dart lib/recorder.dart
flutter test
```

## 本次改动内容

### lib/recorder.dart
- 新增字段：`tripMaxAccelG`、`tripMaxBrakeG`、`tripMaxRightG`、`tripMaxLeftG`
- `onSensor` 中按方向累计峰值（只增不减）
- `start()` 开录时四向峰值归零

### lib/widgets.dart
- `GCirlce` / `GCirlcePainter` 重写为深色 G 表盘：
  - 圆心大数字 = 合成 G（√(纵向²+横向²)），带「合成」标注
  - 外圈随合成值变色（沿用 <0.3g 绿 / <0.5g 黄 / 否则红）
  - 十字轴刻度 + 急弯阈值虚线环（弱化）
  - 5 秒矢量拖尾
  - 四边本趟峰值：仅 `size >= 150` 时显示（详情页），小盘不显示
- 新增可选参数：`maxAccelG / maxBrakeG / maxRightG / maxLeftG`
  （不传时按 `peakLong / peakLat` 符号推导，向后兼容）

### lib/main.dart
- 记录页 `GCirlce(size: 110)` 传入四向峰值
- G 值详情页 `GCirlce(size: 260)` 传入四向峰值
- 详情页表盘下方新增图例：
  「四边数字 = 本趟各方向峰值（上加速 · 下刹车 · 右右转 · 左左转）」

## 注意

- 本包**不包含**此前的 GPS 精度修复（`lib/blediy_gps.dart`、
  `android/.../MainActivity.kt`）和固件工程（`firmware/`）。
  如需一并打包请说明。
- 沙箱环境没有 Flutter SDK，未执行 `flutter analyze` / 测试；
  请在本地按上面的命令验证。
- 建议先提交或 stash 本地改动，再覆盖，方便对比与回滚。
