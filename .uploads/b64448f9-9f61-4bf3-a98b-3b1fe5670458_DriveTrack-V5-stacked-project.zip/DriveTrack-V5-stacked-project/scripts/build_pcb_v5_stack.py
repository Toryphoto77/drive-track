#!/usr/bin/env python3
"""Build DriveTrack PCB V5 stacked (52 x 70 mm, 4-layer).

The 104060 cell sits UNDER the PCB (not beside it). Inspection layout,
not a manufacturing release. Run under KiCad 9.0.2.
"""
from __future__ import annotations

import math
import os
import sys
import uuid
from collections import defaultdict

import pcbnew

HERE = os.path.dirname(os.path.abspath(__file__))
PROJ = os.path.normpath(os.path.join(HERE, "..", "DriveTrack-PCB-V5"))
BOARD_PATH = os.path.join(PROJ, "drivetrack-pcb-v5.kicad_pcb")
KFP = "/usr/share/kicad/footprints"
DTFP = os.path.join(PROJ, "DriveTrack.pretty")

W, H = 52.0, 70.0
CORNER_R = 2.0
USB_X = 26.0
USB_Y = 64.77          # edge 70 - 5.23 (shell to origin), same relation as V4.5/V5
NOTCH_W = 9.20
NOTCH_FLOOR = 65.50    # 4.50 mm deep notch
EDGE_CLR = 0.25

# 104060 cell under the board. 60 mm length aligned with board Y=2..62,
# leaving an 8 mm USB-end strip (Y=62..70) so the mid-mount USB shell
# and two mounting posts do not sit through the pouch. The 12 mm leftover
# strip is X=40..52 (cell is 40 mm wide).
CELL_X0, CELL_Y0 = 0.00, 2.00
CELL_X1, CELL_Y1 = 40.00, 62.00

# All four NPTH holes sit OUTSIDE the cell footprint (leftover strip and
# the USB-end keep-out). Never through the pouch.
MH = {
    "MH1": (46.40, 3.50),    # leftover, FRONT
    "MH2": (46.40, 66.50),   # leftover, USB
    "MH3": (3.20, 66.50),    # USB-end strip, -X
    "MH4": (36.40, 66.50),   # USB-end strip, east of the USB notch
}
MH_DRILL = 2.2

# LED row under the lid window (4 gauge + 1 status), 0805, y near FRONT
LED_Y = 3.20
LED_XS = [9.00, 13.20, 17.40, 21.60, 25.80]  # DS1..DS5

# Major ICs / connectors (x, y, rot_deg)
ANT1_XY = (16.80, 19.40)
U1_XY = (40.60, 16.50)
U1_ROT = 0.0
# U2 is auto-placed for a short RF run
U3_XY = (16.00, 49.10)
U3_ROT = 0.0
U4_XY = (4.40, 50.00)
U4_ROT = 0.0
U5_XY = (8.40, 56.00)
U5_ROT = 0.0
U6_XY = (24.20, 56.00)
U6_ROT = 0.0
L1_XY = (17.00, 55.00)
L1_ROT = 0.0
L2_XY = (29.00, 56.00)
L2_ROT = 0.0
J2_XY = (USB_X, USB_Y)
J2_ROT = 0.0
# J1 / U2 set in code after measuring footprints
J3_XY = (49.20, 60.00)
J3_ROT = 270.0          # mating face toward -X; plug stays on the board
SW1_XY = (33.60, 30.20)
SW2_XY = (39.80, 30.20)

FP_LIBS = {
    "LED_SMD:LED_0805_2012Metric": (f"{KFP}/LED_SMD.pretty", "LED_0805_2012Metric"),
    "Package_TO_SOT_SMD:SOT-23": (f"{KFP}/Package_TO_SOT_SMD.pretty", "SOT-23"),
    "Resistor_SMD:R_0603_1608Metric": (f"{KFP}/Resistor_SMD.pretty", "R_0603_1608Metric"),
    "Capacitor_SMD:C_0603_1608Metric": (f"{KFP}/Capacitor_SMD.pretty", "C_0603_1608Metric"),
    "Button_Switch_SMD:SW_SPST_EVQP7A": (f"{KFP}/Button_Switch_SMD.pretty", "SW_SPST_EVQP7A"),
    "TestPoint:TestPoint_Pad_D1.5mm": (f"{KFP}/TestPoint.pretty", "TestPoint_Pad_D1.5mm"),
    "TestPoint:TestPoint_Pad_D1.0mm": (f"{KFP}/TestPoint.pretty", "TestPoint_Pad_D1.0mm"),
    "DriveTrack:MountingHole_2.2mm": (DTFP, "MountingHole_2.2mm"),
}


def mm(v):
    return pcbnew.FromMM(float(v))


def to_mm(v):
    return pcbnew.ToMM(v)


def xy(x, y):
    return pcbnew.VECTOR2I(mm(x), mm(y))


def ensure_net(board, name):
    n = board.FindNet(name)
    if n is not None and n.GetNetCode() > 0:
        return n
    ni = pcbnew.NETINFO_ITEM(board, name)
    board.Add(ni)
    return board.FindNet(name)


def load_fp(lib_colon_name):
    lib, name = FP_LIBS[lib_colon_name]
    fp = pcbnew.FootprintLoad(lib, name)
    if fp is None:
        raise RuntimeError(f"failed to load {lib_colon_name} from {lib}")
    return fp


def set_fp_at(fp, x, y, rot=0):
    fp.SetPosition(xy(x, y))
    fp.SetOrientationDegrees(rot)


def body_bbox(fp):
    """Body used for packing: courtyard or pad hull, not silk reference text.

    ANT1 only has a feed pad, so it is handled as a 25 x 25 mm square.
    Large connectors / modules fall back to the KiCad footprint bbox.
    """
    ref = fp.GetReference()
    if ref == "ANT1":
        x, y = to_mm(fp.GetPosition().x), to_mm(fp.GetPosition().y)
        return (x - 12.70, y - 12.70, x + 12.70, y + 12.70)
    bb = courtyard_bbox(fp)
    if (bb[2] - bb[0]) >= 1.0 and (bb[3] - bb[1]) >= 1.0:
        return bb
    if ref in {"U1", "U2", "J1", "J2", "J3", "L1", "U5", "U7", "SW1", "SW2"}:
        box = fp.GetBoundingBox(False, False)
        return (to_mm(box.GetLeft()), to_mm(box.GetTop()),
                to_mm(box.GetRight()), to_mm(box.GetBottom()))
    # pad hull + 0.25 mm
    xs, ys = [], []
    for p in fp.Pads():
        pos = p.GetPosition()
        size = p.GetSize()
        xs += [to_mm(pos.x) - to_mm(size.x) / 2, to_mm(pos.x) + to_mm(size.x) / 2]
        ys += [to_mm(pos.y) - to_mm(size.y) / 2, to_mm(pos.y) + to_mm(size.y) / 2]
    if xs:
        return (min(xs) - 0.25, min(ys) - 0.25, max(xs) + 0.25, max(ys) + 0.25)
    box = fp.GetBoundingBox(False, False)
    return (to_mm(box.GetLeft()), to_mm(box.GetTop()),
            to_mm(box.GetRight()), to_mm(box.GetBottom()))


def courtyard_bbox(fp):
    """Return (xmin, ymin, xmax, ymax) in mm, world coords, from courtyard or pads."""
    try:
        poly = fp.GetCourtyard(pcbnew.F_Cu)
    except TypeError:
        try:
            poly = fp.GetCourtyard()
        except Exception:
            poly = None
    pts = []
    if poly is not None:
        try:
            box = poly.BBox()
            if box.GetWidth() > 0 and box.GetHeight() > 0:
                return (to_mm(box.GetLeft()), to_mm(box.GetTop()),
                        to_mm(box.GetRight()), to_mm(box.GetBottom()))
        except Exception:
            pass
    # fallback: pads + 0.25 mm
    xs, ys = [], []
    for p in fp.Pads():
        pos = p.GetPosition()
        size = p.GetSize()
        xs += [to_mm(pos.x) - to_mm(size.x) / 2, to_mm(pos.x) + to_mm(size.x) / 2]
        ys += [to_mm(pos.y) - to_mm(size.y) / 2, to_mm(pos.y) + to_mm(size.y) / 2]
    if not xs:
        bb = fp.GetBoundingBox(False, False)
        return (to_mm(bb.GetLeft()), to_mm(bb.GetTop()),
                to_mm(bb.GetRight()), to_mm(bb.GetBottom()))
    return (min(xs) - 0.25, min(ys) - 0.25, max(xs) + 0.25, max(ys) + 0.25)


def overlap(a, b, gap=0.0):
    return not (a[2] + gap <= b[0] or b[2] + gap <= a[0] or a[3] + gap <= b[1] or b[3] + gap <= a[1])


def pad_world(fp, number):
    for p in fp.Pads():
        if p.GetNumber() == str(number):
            pos = p.GetPosition()
            return (to_mm(pos.x), to_mm(pos.y), p)
    return None


def assign_pad_net(fp, number, board, netname):
    n = ensure_net(board, netname)
    for p in fp.Pads():
        if p.GetNumber() == str(number):
            p.SetNet(n)
            return True
    return False


def add_fp(board, lib_colon, ref, value, x, y, rot, pad_nets=None):
    fp = load_fp(lib_colon)
    fp.SetReference(ref)
    fp.SetValue(value)
    set_fp_at(fp, x, y, rot)
    board.Add(fp)
    if pad_nets:
        for num, net in pad_nets.items():
            ok = assign_pad_net(fp, num, board, net)
            if not ok:
                print(f"  WARN: {ref} pad {num} not found for net {net}")
    return fp


def delete_all_tracks_zones_drawings(board):
    for t in list(board.GetTracks()):
        board.Remove(t)
    for z in list(board.Zones()):
        board.Remove(z)
    for d in list(board.GetDrawings()):
        board.Remove(d)


def delete_fp(board, ref):
    """Do not use BOARD.Remove on footprints under KiCad 9 Python (it can crash).
    Retired parts are stripped from the template instead. This is a safe no-op
    if the ref is already gone, and a hard error if it is still present.
    """
    for fp in list(board.GetFootprints()):
        try:
            r = fp.GetReference()
        except AttributeError:
            continue
        if r == ref:
            raise RuntimeError(
                f"{ref} is still on the board; strip it from the sexp template instead of Remove()"
            )
    return False


def find_fp(board, ref):
    for fp in board.GetFootprints():
        if fp.GetReference() == ref:
            return fp
    return None


def add_edge_line(board, a, b, width=0.05):
    s = pcbnew.PCB_SHAPE(board)
    s.SetShape(pcbnew.SHAPE_T_SEGMENT)
    s.SetStart(xy(*a))
    s.SetEnd(xy(*b))
    s.SetLayer(pcbnew.Edge_Cuts)
    s.SetWidth(mm(width))
    board.Add(s)


def add_edge_arc(board, start, mid, end, width=0.05):
    s = pcbnew.PCB_SHAPE(board)
    s.SetShape(pcbnew.SHAPE_T_ARC)
    s.SetStart(xy(*start))
    s.SetEnd(xy(*end))
    if hasattr(s, "SetArcMid"):
        s.SetArcMid(xy(*mid))
    else:
        # fallback: SetCenter
        s.SetCenter(xy(*mid))
    s.SetLayer(pcbnew.Edge_Cuts)
    s.SetWidth(mm(width))
    board.Add(s)


def add_silk_text(board, text, x, y, size=1.0, layer=None, rot=0, thick=0.15):
    t = pcbnew.PCB_TEXT(board)
    t.SetText(text)
    t.SetPosition(xy(x, y))
    t.SetLayer(layer or pcbnew.F_SilkS)
    t.SetTextSize(pcbnew.VECTOR2I(mm(size), mm(size)))
    t.SetTextThickness(mm(thick))
    if rot:
        t.SetTextAngle(pcbnew.EDA_ANGLE(rot, pcbnew.DEGREES_T))
    board.Add(t)
    return t


def add_silk_line(board, a, b, width=0.15, layer=None):
    s = pcbnew.PCB_SHAPE(board)
    s.SetShape(pcbnew.SHAPE_T_SEGMENT)
    s.SetStart(xy(*a))
    s.SetEnd(xy(*b))
    s.SetLayer(layer or pcbnew.F_SilkS)
    s.SetWidth(mm(width))
    board.Add(s)


def add_silk_rect(board, a, b, width=0.12, layer=None):
    x0, y0 = a
    x1, y1 = b
    add_silk_line(board, (x0, y0), (x1, y0), width, layer)
    add_silk_line(board, (x1, y0), (x1, y1), width, layer)
    add_silk_line(board, (x1, y1), (x0, y1), width, layer)
    add_silk_line(board, (x0, y1), (x0, y0), width, layer)


def add_keepout_rect(board, a, b, layers=None, name="keepout"):
    z = pcbnew.ZONE(board)
    z.SetIsRuleArea(True)
    z.SetDoNotAllowTracks(True)
    z.SetDoNotAllowVias(True)
    z.SetDoNotAllowPads(False)
    z.SetDoNotAllowFootprints(False)
    z.SetDoNotAllowCopperPour(True)
    if hasattr(z, "SetZoneName"):
        z.SetZoneName(name)
    ls = pcbnew.LSET()
    for lyr in (layers or [pcbnew.F_Cu]):
        ls.AddLayer(lyr)
    if hasattr(z, "SetLayerSet"):
        z.SetLayerSet(ls)
    else:
        z.SetLayer(layers[0] if layers else pcbnew.F_Cu)
    z.Outline().NewOutline()
    for x, y in ((a[0], a[1]), (b[0], a[1]), (b[0], b[1]), (a[0], b[1])):
        z.Outline().Append(mm(x), mm(y))
    board.Add(z)
    return z


def build_outline(board):
    """Rounded-rect 52x60 with a mid-mount USB notch on the south edge."""
    r = CORNER_R
    # corners: NW, NE, SE (right of notch), notch, SE (left of notch wait), SW
    # Y=0 is north (LED), Y=H is south (USB)
    nx0 = USB_X - NOTCH_W / 2
    nx1 = USB_X + NOTCH_W / 2
    # Midpoints of 90-degree corner arcs (toward the outside of the fillet)
    # NW: (0,r) -> (r,0), mid ~ (r-r/sqrt2, r-r/sqrt2) = (0.5858, 0.5858) for r=2
    k = r * (1 - math.sqrt(2) / 2)  # 0.5858 for r=2
    # Top edge
    add_edge_line(board, (r, 0), (W - r, 0))
    add_edge_arc(board, (W - r, 0), (W - k, k), (W, r))  # NE
    add_edge_line(board, (W, r), (W, H - r))
    add_edge_arc(board, (W, H - r), (W - k, H - k), (W - r, H))  # SE
    add_edge_line(board, (W - r, H), (nx1, H))
    # notch: down? The USB tongue needs a cut INTO the board, so y decreases from H to NOTCH_FLOOR
    add_edge_line(board, (nx1, H), (nx1, NOTCH_FLOOR))
    add_edge_line(board, (nx1, NOTCH_FLOOR), (nx0, NOTCH_FLOOR))
    add_edge_line(board, (nx0, NOTCH_FLOOR), (nx0, H))
    add_edge_line(board, (nx0, H), (r, H))
    add_edge_arc(board, (r, H), (k, H - k), (0, H - r))  # SW
    add_edge_line(board, (0, H - r), (0, r))
    add_edge_arc(board, (0, r), (k, k), (r, 0))  # NW


def replace_mounting_holes(board):
    for ref, (x, y) in MH.items():
        fp = load_fp("DriveTrack:MountingHole_2.2mm")
        fp.SetReference(ref)
        fp.SetValue("MH 2.2mm NPTH")
        set_fp_at(fp, x, y, 0)
        # board-only already
        board.Add(fp)


def place_existing(board, ref, x, y, rot=None):
    fp = find_fp(board, ref)
    if fp is None:
        print(f"  WARN: missing existing fp {ref}")
        return None
    set_fp_at(fp, x, y, fp.GetOrientationDegrees() if rot is None else rot)
    return fp


# ---------------------------------------------------------------------------
# Placement of reused V4.5 footprints + new V5 parts
# ---------------------------------------------------------------------------

def place_u2_for_short_rf(board):
    """Place NEO-M9N just south of the patch with RF_IN facing the feed."""
    ant = find_fp(board, "ANT1")
    u2 = find_fp(board, "U2")
    feed = pad_world(ant, "1")
    fx, fy = feed[0], feed[1]
    best = None
    # Candidate centers just south of the 25x25 patch
    patch_bottom = ANT1_XY[1] + 12.55
    for rot in (0, 90, 180, 270, -90):
        for cx in (16.8, 14.5, 19.0, 12.5, 21.0):
            for cy in (38.4, 39.2, 40.0, 37.6, 41.0, 36.8):
                if cy < patch_bottom + 0.6:
                    continue
                set_fp_at(u2, cx, cy, rot)
                rf = pad_world(u2, "11")
                if rf is None:
                    continue
                dist = math.hypot(rf[0] - fx, rf[1] - fy)
                # RF pad should be north of module / close to feed, and not under the patch
                if rf[1] < ANT1_XY[1] + 12.0:
                    continue
                bb = courtyard_bbox(u2)
                if bb[0] < 0.4 or bb[2] > W - 0.4 or bb[1] < 0.4 or bb[3] > H - 0.4:
                    continue
                # overlap with ANT1?
                ant_bb = (ANT1_XY[0] - 12.8, ANT1_XY[1] - 12.8, ANT1_XY[0] + 12.8, ANT1_XY[1] + 12.8)
                if overlap(bb, ant_bb, 0.2):
                    continue
                score = dist + (0.2 if rf[1] > fy else 0)
                if best is None or score < best[0]:
                    best = (score, cx, cy, rot, dist, rf)
    if best is None:
        print("  WARN: U2 auto-place failed, using fallback")
        set_fp_at(u2, 16.8, 39.5, -90)
        return
    _, cx, cy, rot, dist, rf = best
    set_fp_at(u2, cx, cy, rot)
    print(f"  U2 at ({cx:.2f},{cy:.2f}) rot {rot}  RF_IN=({rf[0]:.2f},{rf[1]:.2f})  feed run {dist:.2f} mm")
    return (cx, cy, rot, dist)


def place_j1_j3(board):
    """J3 in the leftover strip, mating toward -X so the PH plug stays on
    the board and the pigtail can fold down into the cell bay at X=40,
    near the cell's USB end (Y=62). J1 push-push, 4 mm eject into the
    cavity, not into a wall; open-lid only.
    """
    j1 = find_fp(board, "J1")
    j3 = find_fp(board, "J3")

    set_fp_at(j3, J3_XY[0], J3_XY[1], J3_ROT)
    bb3 = body_bbox(j3)
    print(f"  J3 at {J3_XY} rot {J3_ROT} bb={tuple(round(v,2) for v in bb3)}")
    if bb3[0] < 0.2 or bb3[2] > W + 0.4 or bb3[1] < 0.2 or bb3[3] > H + 0.2:
        print("  WARN: J3 close to or past the board edge")
    # Mating face is the more-western extent at rot 270; plug approaches from -X.
    plug_need = 8.0
    if bb3[0] - plug_need < 0.5:
        print(f"  WARN: J3 plug travel toward -X may be tight (face x={bb3[0]:.2f})")
    else:
        print(f"  J3 plug path on-board: x={bb3[0]-plug_need:.2f}..{bb3[0]:.2f} (above the board, then down at the cell edge)")

    # J1: rot 180 ejects toward -Y (FRONT) into the cavity.
    # Place in the mid-right, south of ESP32 / east of U2, north of J3/USB.
    reserved = [
        (USB_X - 6.0, USB_Y - 6.2, USB_X + 6.0, H + 1.0),
        (ANT1_XY[0] - 13.0, ANT1_XY[1] - 13.0, ANT1_XY[0] + 13.0, ANT1_XY[1] + 13.0),
        (U1_XY[0] - 10.0, U1_XY[1] - 11.0, U1_XY[0] + 10.0, U1_XY[1] + 11.0),
        (U3_XY[0] - 4.0, U3_XY[1] - 3.5, U3_XY[0] + 4.0, U3_XY[1] + 3.5),
        (U4_XY[0] - 2.5, U4_XY[1] - 2.5, U4_XY[0] + 2.5, U4_XY[1] + 2.5),
        (U5_XY[0] - 5.0, U5_XY[1] - 4.0, U5_XY[0] + 5.0, U5_XY[1] + 4.0),
        (U6_XY[0] - 3.5, U6_XY[1] - 3.0, U6_XY[0] + 3.5, U6_XY[1] + 3.0),
        (L1_XY[0] - 5.0, L1_XY[1] - 5.0, L1_XY[0] + 5.0, L1_XY[1] + 5.0),
        bb3,
    ]
    for name, (x, y) in MH.items():
        reserved.append((x - 2.0, y - 2.0, x + 2.0, y + 2.0))
    u2 = find_fp(board, "U2")
    if u2:
        reserved.append(body_bbox(u2))

    chosen = None
    candidates = []
    for rot in (180, 270, 90, 0):
        for cx in (38.0, 39.0, 40.0, 37.0, 41.0, 36.0, 42.0):
            for cy in (44.0, 45.0, 43.0, 46.0, 47.0, 42.0, 48.0, 49.0):
                set_fp_at(j1, cx, cy, rot)
                bb = body_bbox(j1)
                if bb[0] < 0.5 or bb[2] > W - 0.3 or bb[1] < 0.5 or bb[3] > H - 0.3:
                    continue
                if any(overlap(bb, r, 0.30) for r in reserved):
                    continue
                # 4 mm eject travel in the opening direction
                if rot == 180:
                    eject = (bb[0], bb[1] - 4.0, bb[2], bb[1])
                elif rot == 0:
                    eject = (bb[0], bb[3], bb[2], bb[3] + 4.0)
                elif rot == 270:
                    eject = (bb[0] - 4.0, bb[1], bb[0], bb[3])
                else:
                    eject = (bb[2], bb[1], bb[2] + 4.0, bb[3])
                if eject[0] < 0.3 or eject[1] < 0.3 or eject[2] > W - 0.3 or eject[3] > H - 0.3:
                    continue
                if any(overlap(eject, r, 0.15) for r in reserved):
                    continue
                # Prefer eject toward FRONT (rot 180) and not over the GPS patch
                score = abs(cx - 39.0) + abs(cy - 45.0) + (0 if rot == 180 else 8)
                candidates.append((score, cx, cy, rot, bb, eject))
    if candidates:
        candidates.sort()
        _, cx, cy, rot, bb, eject = candidates[0]
        set_fp_at(j1, cx, cy, rot)
        print(f"  J1 at ({cx},{cy}) rot {rot} bb={tuple(round(v,2) for v in bb)} eject={tuple(round(v,2) for v in eject)}")
        chosen = True
    # Frozen stacked placement: eject 4 mm toward FRONT, east of the GPS
    # patch, west of the leftover so J3 keeps a cable path, north of J3.
    set_fp_at(j1, 40.00, 48.20, 180)
    bb = body_bbox(j1)
    print(f"  J1 forced (40.00,48.20) rot 180 bb={tuple(round(v,2) for v in bb)}")


def place_passives_near(board, refs, x0, y0, cols=3, pitch=1.8, rot=0):
    i = 0
    for ref in refs:
        fp = find_fp(board, ref)
        if fp is None:
            continue
        c = i % cols
        r = i // cols
        set_fp_at(fp, x0 + c * pitch, y0 + r * pitch, rot)
        i += 1



MAJOR = {"ANT1","U1","U2","U3","U4","U5","U6","L1","L2","J1","J2","J3","J4",
         "MH1","MH2","MH3","MH4","DS1","DS2","DS3","DS4","DS5","SW1","SW2"}


def place_passives_manual(board):
    """Deterministic packing into known free pockets. Inspection density."""
    # (ref, x, y, rot)
    slots = []
    # West alley, east of the vent wall, west of U2 (U2 starts x~12.7)
    west = [
        "C5", "C6", "C7", "R5", "R6", "R7", "FB1",
        "C8", "C9", "C12", "R11", "R12",
        "C4", "C10", "C11", "R9", "R10",
        "R30", "R31", "C3",
    ]
    xs = [7.20, 9.00, 10.80]
    ys = [33.20 + i * 1.80 for i in range(8)]  # 33.20 .. 45.80
    coords = [(x, y) for y in ys for x in xs]
    for ref, (x, y) in zip(west, coords):
        slots.append((ref, x, y, 0))

    # South of U2 / around U3 (skip U3 at 16,51)
    mid = [
        "C19", "C20", "C23", "R22", "R23", "R24",
        "Q1", "R19", "R20", "R21",
        "C14", "R13", "R14", "R15",
        "C21", "C22",
    ]
    mid_xy = [
        (8.0, 48.40), (10.0, 48.40), (12.0, 48.40), (20.0, 48.40), (22.2, 48.40), (24.4, 48.40),
        (8.0, 50.40), (10.0, 50.40), (12.0, 50.40), (20.0, 50.40), (22.2, 50.40), (24.4, 50.40),
        (26.6, 48.40), (28.8, 48.40), (26.6, 50.40), (28.8, 50.40),
    ]
    for ref, (x, y) in zip(mid, mid_xy):
        slots.append((ref, x, y, 0))

    # Power caps / sense near U5 and L1, west and north of the inductors
    pwr = [
        ("C16", 5.80, 53.40, 0),
        ("C18", 8.00, 53.40, 0),
        ("C24", 5.80, 55.40, 90),
        ("C25", 5.80, 57.40, 0),
        ("R4",  5.80, 59.10, 0),
        ("R27", 8.00, 59.10, 0),
    ]
    slots.extend(pwr)

    # USB ESD / CC, east of the receptacle, west of MH4
    esd = ["D1", "D2", "D3", "R16", "R17", "R18"]
    for i, ref in enumerate(esd):
        slots.append((ref, 32.2 + (i % 3) * 2.0, 60.40 + (i // 3) * 2.0, 0))

    # ESP decoupling in leftover, south of U1, west of the board edge
    esp = ["C1", "C2", "C13", "C15", "R1", "R2", "R3"]
    for i, ref in enumerate(esp):
        slots.append((ref, 50.20 if i % 2 else 48.20, 27.40 + (i // 2) * 1.70, 0))

    # DNI / remaining
    slots.append(("U7", 49.20, 34.80, 0))
    slots.append(("J9", 49.40, 28.40, 90))
    slots.append(("J4", 49.50, 30.60, 0))

    placed = 0
    missing = []
    for ref, x, y, rot in slots:
        fp = find_fp(board, ref)
        if fp is None:
            missing.append(ref)
            continue
        set_fp_at(fp, x, y, rot)
        placed += 1
    print(f"  manual passives placed {placed}, missing {missing}")

    # Anything still off-board: dump along the west alley overflow column
    overflow_y = 33.20
    extra = 0
    for fp in board.GetFootprints():
        ref = fp.GetReference()
        x, y = to_mm(fp.GetPosition().x), to_mm(fp.GetPosition().y)
        if x >= -1 and y >= -1:
            continue
        set_fp_at(fp, 6.00, overflow_y, fp.GetOrientationDegrees())
        print(f"  extra {ref} at (6.00,{overflow_y:.2f})")
        overflow_y += 1.70
        extra += 1
    return placed, extra


def pack_passives_into_free_space(board):
    """Move any non-major footprint whose courtyard overlaps a major part
    (or another already accepted part) onto a free 2.0 mm grid cell.
    """
    def bbs():
        out = []
        for fp in board.GetFootprints():
            ref = fp.GetReference()
            if ref.startswith("MH"):
                continue
            out.append((ref, body_bbox(fp), fp))
        return out

    def blocked(bb, ignore):
        if bb[0] < 0.7 or bb[1] < 5.0 or bb[2] > W - 0.7 or bb[3] > H - 1.2:
            # keep LED row (y~3.2) and USB edge clear; pack in the mid-band
            return True
        # USB keepout and mounting holes
        if overlap(bb, (USB_X - 6.0, USB_Y - 6.2, USB_X + 6.0, H + 1), 0.2):
            return True
        for _, (hx, hy) in MH.items():
            if overlap(bb, (hx - 2.0, hy - 2.0, hx + 2.0, hy + 2.0), 0.15):
                return True
        for ref, b2, _ in bbs():
            if ref in ignore:
                continue
            if overlap(bb, b2, 0.18):
                return True
        return False

    # Park every non-major part off the board first so leftover seed
    # positions cannot block the packer, then drop them onto a 1.5 mm grid.
    movers = []
    for fp in list(board.GetFootprints()):
        ref = fp.GetReference()
        keep = {"Q3", "R33", "R35", "R36", "C26", "R26", "R32"}
        if ref in MAJOR or ref in keep or ref.startswith("MH") or ref.startswith("DS") or ref.startswith("TP") or ref.startswith("J5"):
            continue
        movers.append(fp)
        set_fp_at(fp, -20.0, -20.0 - 3.0 * len(movers), fp.GetOrientationDegrees())

    moved = 0
    xs = [x / 10 for x in range(70, 505, 15)]  # 7.0 .. 50.4 step 1.5
    ys = [y / 10 for y in range(80, 630, 15)]  # 8.0 .. 63.0 step 1.5
    gps_bb = (ANT1_XY[0] - 13.0, ANT1_XY[1] - 13.0, ANT1_XY[0] + 13.0, ANT1_XY[1] + 13.0)
    for fp in movers:
        ref = fp.GetReference()
        # temporary bbox at the parked location is useless; use current size
        # by placing at origin briefly
        rot = fp.GetOrientationDegrees()
        set_fp_at(fp, 20.0, 20.0, rot)
        bb = body_bbox(fp)
        w = bb[2] - bb[0]
        h = bb[3] - bb[1]
        set_fp_at(fp, -20.0, -20.0, rot)
        found = False
        for y in ys:
            for x in xs:
                trial = (x - w / 2, y - h / 2, x + w / 2, y + h / 2)
                if overlap(trial, gps_bb, 0.3):
                    continue
                if not blocked(trial, ignore={ref}):
                    set_fp_at(fp, x, y, rot)
                    moved += 1
                    found = True
                    break
            if found:
                break
        if not found:
            # last resort: first remaining free cell that is not under U1 / ANT1
            placed = False
            for y in ys:
                for x in xs:
                    trial = (x - w / 2, y - h / 2, x + w / 2, y + h / 2)
                    if overlap(trial, gps_bb, 0.3):
                        continue
                    if trial[0] > 30.0 and trial[1] < 28.0:
                        continue  # under / beside the ESP32 module
                    if not blocked(trial, ignore={ref}):
                        set_fp_at(fp, x, y, rot)
                        print(f"  overflow {ref} at ({x:.1f},{y:.1f})")
                        moved += 1
                        placed = True
                        break
                if placed:
                    break
            if not placed:
                print(f"  WARN: no free cell for {ref} — left off-board, needs hand placement")
    return moved


def report_collisions(board, gap=0.15):
    fps = list(board.GetFootprints())
    boxes = []
    for fp in fps:
        ref = fp.GetReference()
        # skip NPTH holes in courtyard tests (they have no courtyard)
        if ref.startswith("MH"):
            continue
        if ref.startswith("TP") or ref.startswith("J5"):
            continue  # 1.0/1.5 mm pads on a tight row are expected
        boxes.append((ref, body_bbox(fp)))
    hits = []
    for i, (r1, b1) in enumerate(boxes):
        for r2, b2 in boxes[i + 1:]:
            if overlap(b1, b2, gap):
                hits.append((r1, r2, b1, b2))
        # board edge
        if b1[0] < EDGE_CLR - 0.05 or b1[1] < EDGE_CLR - 0.05 or b1[2] > W - EDGE_CLR + 0.4 or b1[3] > H + 1.0:
            # USB parts may extend into the notch / past the south edge — that's expected for J2
            if r1 != "J2" and b1[0] < -0.2 or (r1 not in ("J2", "J3") and b1[2] > W + 0.3):
                hits.append((r1, "EDGE", b1, None))
    print(f"  courtyard overlaps (gap={gap}): {len(hits)}")
    for h in hits[:40]:
        print("   ", h[0], h[1], tuple(round(x, 2) for x in h[2]) if h[2] else "")
    return hits


# ---------------------------------------------------------------------------
# Routing
# ---------------------------------------------------------------------------

def add_track(board, a, b, width, layer, netcode):
    t = pcbnew.PCB_TRACK(board)
    t.SetStart(xy(*a))
    t.SetEnd(xy(*b))
    t.SetWidth(mm(width))
    t.SetLayer(layer)
    t.SetNetCode(netcode)
    board.Add(t)
    return t


def add_via(board, pt, netcode, size=0.6, drill=0.3):
    v = pcbnew.PCB_VIA(board)
    v.SetPosition(xy(*pt))
    if hasattr(v, "SetFrontWidth"):
        v.SetFrontWidth(mm(size))
    else:
        try:
            v.SetWidth(mm(size))
        except TypeError:
            pass
    v.SetDrill(mm(drill))
    if hasattr(v, "SetViaType"):
        v.SetViaType(pcbnew.VIATYPE_THROUGH)
    v.SetNetCode(netcode)
    if hasattr(v, "SetLayerPair"):
        v.SetLayerPair(pcbnew.F_Cu, pcbnew.B_Cu)
    board.Add(v)
    return v


def netclass_width(board, netname):
    # defaults from the V4.5 project
    if netname in ("BAT", "+5V", "VBUS", "GPS_VCC") or "U5-SW" in netname or "U6-SW" in netname or "U6-VBST" in netname or netname.endswith("-SW"):
        return 0.50
    if netname in ("+3V3",):
        return 0.35
    if netname in ("GPS_RF", "Net-(ANT1-FEED)", "Net-(U2-VCC_RF)"):
        return 0.40
    if netname in ("USB_DP", "USB_DM"):
        return 0.25
    return 0.25


def route_straight_or_elbow(board, a, b, width, layer, netcode):
    """Manhattan elbow if not colinear."""
    ax, ay = a
    bx, by = b
    if abs(ax - bx) < 0.01 or abs(ay - by) < 0.01:
        add_track(board, a, b, width, layer, netcode)
        return
    mid = (bx, ay)
    add_track(board, a, mid, width, layer, netcode)
    add_track(board, mid, b, width, layer, netcode)


def collect_pads_by_net(board):
    nets = defaultdict(list)
    for fp in board.GetFootprints():
        for p in fp.Pads():
            name = p.GetNetname()
            if not name or name == "":
                continue
            pos = p.GetPosition()
            nets[name].append({
                "ref": fp.GetReference(),
                "pad": p.GetNumber(),
                "x": to_mm(pos.x),
                "y": to_mm(pos.y),
                "layer_set": p.GetLayerSet(),
                "is_smd": p.GetAttribute() == pcbnew.PAD_ATTRIB_SMD,
                "padobj": p,
                "fp": fp,
            })
    return nets


class GridRouter:
    """Simple 2-layer (F/B) A* with vias, 0.1 mm grid."""

    def __init__(self, board, pitch=0.10, clearance=0.20):
        self.board = board
        self.pitch = pitch
        self.clearance = clearance
        self.nx = int(round(W / pitch)) + 3
        self.ny = int(round(H / pitch)) + 3
        # occupancy[layer][ix][iy] = True if blocked
        # layer 0 = F.Cu, 1 = B.Cu
        self.occ = [bytearray(self.nx * self.ny) for _ in range(2)]
        self._fill_obstacles()

    def idx(self, ix, iy):
        return iy * self.nx + ix

    def world_to_g(self, x, y):
        return int(round(x / self.pitch)), int(round(y / self.pitch))

    def g_to_world(self, ix, iy):
        return ix * self.pitch, iy * self.pitch

    def _fill_obstacles(self):
        infl = self.clearance + 0.13  # half of 0.25 track + clearance
        # board edge
        for iy in range(self.ny):
            for ix in range(self.nx):
                x, y = self.g_to_world(ix, iy)
                if x < EDGE_CLR or y < EDGE_CLR or x > W - EDGE_CLR or y > H - EDGE_CLR:
                    # allow USB notch interior (cutout is not copper anyway; treat as outside)
                    self.occ[0][self.idx(ix, iy)] = 1
                    self.occ[1][self.idx(ix, iy)] = 1
        # USB notch is outside the board
        nx0 = USB_X - NOTCH_W / 2
        nx1 = USB_X + NOTCH_W / 2
        for iy in range(self.ny):
            for ix in range(self.nx):
                x, y = self.g_to_world(ix, iy)
                if y > NOTCH_FLOOR and nx0 < x < nx1:
                    self.occ[0][self.idx(ix, iy)] = 1
                    self.occ[1][self.idx(ix, iy)] = 1
        # pads
        for fp in self.board.GetFootprints():
            for p in fp.Pads():
                pos = p.GetPosition()
                size = p.GetSize()
                cx, cy = to_mm(pos.x), to_mm(pos.y)
                wx, hy = to_mm(size.x) / 2 + infl, to_mm(size.y) / 2 + infl
                ix0, iy0 = self.world_to_g(cx - wx, cy - hy)
                ix1, iy1 = self.world_to_g(cx + wx, cy + hy)
                smd = p.GetAttribute() == pcbnew.PAD_ATTRIB_SMD
                layers = [0, 1]
                if smd:
                    # only the copper side of the pad
                    try:
                        if p.IsOnLayer(pcbnew.F_Cu) and not p.IsOnLayer(pcbnew.B_Cu):
                            layers = [0]
                        elif p.IsOnLayer(pcbnew.B_Cu) and not p.IsOnLayer(pcbnew.F_Cu):
                            layers = [1]
                    except Exception:
                        layers = [0]
                for iy in range(max(0, iy0), min(self.ny, iy1 + 1)):
                    for ix in range(max(0, ix0), min(self.nx, ix1 + 1)):
                        for lyr in layers:
                            self.occ[lyr][self.idx(ix, iy)] = 1
        # GPS patch keepout on F.Cu (leave a corridor at the feed later)
        ax, ay = ANT1_XY
        for iy in range(self.ny):
            for ix in range(self.nx):
                x, y = self.g_to_world(ix, iy)
                if abs(x - ax) <= 12.6 and abs(y - ay) <= 12.6:
                    self.occ[0][self.idx(ix, iy)] = 1
        # Existing tracks and vias (so a later pass cannot short the RF / USB pair)
        lyr_i = {pcbnew.F_Cu: 0, pcbnew.B_Cu: 1}
        for tr in self.board.GetTracks():
            try:
                if tr.GetClass() == "PCB_VIA" or (hasattr(pcbnew, "PCB_VIA") and isinstance(tr, pcbnew.PCB_VIA)):
                    pos = tr.GetPosition()
                    self.mark_track((to_mm(pos.x), to_mm(pos.y)), (to_mm(pos.x), to_mm(pos.y)), 0)
                    self.mark_track((to_mm(pos.x), to_mm(pos.y)), (to_mm(pos.x), to_mm(pos.y)), 1)
                    continue
            except Exception:
                pass
            try:
                lyr = tr.GetLayer()
                if lyr not in lyr_i:
                    continue
                a = (to_mm(tr.GetStart().x), to_mm(tr.GetStart().y))
                b = (to_mm(tr.GetEnd().x), to_mm(tr.GetEnd().y))
                self.mark_track(a, b, lyr_i[lyr])
            except Exception:
                continue

    def unblock_pad(self, x, y, layer, radius=0.6):
        ix0, iy0 = self.world_to_g(x - radius, y - radius)
        ix1, iy1 = self.world_to_g(x + radius, y + radius)
        for iy in range(max(0, iy0), min(self.ny, iy1 + 1)):
            for ix in range(max(0, ix0), min(self.nx, ix1 + 1)):
                self.occ[layer][self.idx(ix, iy)] = 0

    def mark_track(self, a, b, layer):
        # rasterize a segment as obstacle
        ax, ay = a
        bx, by = b
        n = max(1, int(math.hypot(bx - ax, by - ay) / self.pitch))
        infl = 1  # 1 cell
        for i in range(n + 1):
            t = i / n
            x = ax + t * (bx - ax)
            y = ay + t * (by - ay)
            ix, iy = self.world_to_g(x, y)
            for dy in range(-infl, infl + 1):
                for dx in range(-infl, infl + 1):
                    jx, jy = ix + dx, iy + dy
                    if 0 <= jx < self.nx and 0 <= jy < self.ny:
                        self.occ[layer][self.idx(jx, jy)] = 1

    def route(self, a, b, netcode, width, allow_via=True):
        """A* from a to b. Returns True if routed."""
        start = (*self.world_to_g(a[0], a[1]), 0)
        goal = (*self.world_to_g(b[0], b[1]), 0)
        # also try B start/goal if needed
        starts = [start]
        goals = {goal, (goal[0], goal[1], 1)}
        if allow_via:
            starts.append((start[0], start[1], 1))
        # unblock endpoints
        for lyr in (0, 1):
            self.unblock_pad(a[0], a[1], lyr, 0.5)
            self.unblock_pad(b[0], b[1], lyr, 0.5)

        from heapq import heappush, heappop
        INF = 10 ** 9
        def heur(s):
            return (abs(s[0] - goal[0]) + abs(s[1] - goal[1])) + (4 if s[2] != 0 else 0)

        openh = []
        came = {}
        gscore = {}
        for s in starts:
            gscore[s] = 0
            heappush(openh, (heur(s), 0, s))
        found = None
        max_iter = 80000
        it = 0
        while openh and it < max_iter:
            it += 1
            _, g, u = heappop(openh)
            if u in goals:
                found = u
                break
            if g != gscore.get(u, INF):
                continue
            ux, uy, ul = u
            # 4-neighbors
            for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                vx, vy = ux + dx, uy + dy
                if not (0 <= vx < self.nx and 0 <= vy < self.ny):
                    continue
                if self.occ[ul][self.idx(vx, vy)]:
                    continue
                v = (vx, vy, ul)
                ng = g + 1
                if ng < gscore.get(v, INF):
                    gscore[v] = ng
                    came[v] = u
                    heappush(openh, (ng + heur(v), ng, v))
            if allow_via:
                vl = 1 - ul
                v = (ux, uy, vl)
                if not self.occ[vl][self.idx(ux, uy)]:
                    ng = g + 8  # via penalty
                    if ng < gscore.get(v, INF):
                        gscore[v] = ng
                        came[v] = u
                        heappush(openh, (ng + heur(v), ng, v))
        if found is None:
            return False
        # reconstruct
        path = [found]
        cur = found
        while cur in came:
            cur = came[cur]
            path.append(cur)
        path.reverse()
        # emit tracks / vias
        layer_of = {0: pcbnew.F_Cu, 1: pcbnew.B_Cu}
        i = 0
        while i < len(path) - 1:
            if path[i][2] != path[i + 1][2]:
                # via
                x, y = self.g_to_world(path[i][0], path[i][1])
                add_via(self.board, (x, y), netcode)
                i += 1
                continue
            # gather a straight run
            j = i + 1
            dx = path[j][0] - path[i][0]
            dy = path[j][1] - path[i][1]
            while j + 1 < len(path) and path[j + 1][2] == path[i][2]:
                ndx = path[j + 1][0] - path[j][0]
                ndy = path[j + 1][1] - path[j][1]
                if (ndx, ndy) != (dx, dy):
                    break
                j += 1
            a0 = self.g_to_world(path[i][0], path[i][1])
            a1 = self.g_to_world(path[j][0], path[j][1])
            add_track(self.board, a0, a1, width, layer_of[path[i][2]], netcode)
            self.mark_track(a0, a1, path[i][2])
            i = j
        return True


def route_specials(board):
    """Hand-route GPS RF (50 ohm on F.Cu) and short USB / power stubs."""
    ant = find_fp(board, "ANT1")
    r8 = find_fp(board, "R8")
    u2 = find_fp(board, "U2")
    feed = pad_world(ant, "1")
    # R8 is 0R on the feed: pad1 toward ANT, pad2 toward U2 (V4.5 convention)
    # Place R8 on the path first if not already
    if r8 and feed:
        rf = pad_world(u2, "11")
        # put R8 between feed and RF_IN
        mx = (feed[0] + rf[0]) / 2
        my = (feed[1] + rf[1]) / 2
        # orient R8 along the run
        ang = math.degrees(math.atan2(rf[1] - feed[1], rf[0] - feed[0]))
        set_fp_at(r8, mx, my, ang)
        p1 = pad_world(r8, "1")
        p2 = pad_world(r8, "2")
        # decide which pad is closer to the feed
        if math.hypot(p1[0] - feed[0], p1[1] - feed[1]) > math.hypot(p2[0] - feed[0], p2[1] - feed[1]):
            p1, p2 = p2, p1
        # ANT1 feed net may be Net-(ANT1-FEED) or GPS_RF depending on R8
        n1 = p1[2].GetNetname()
        n2 = p2[2].GetNetname()
        w1 = 0.40
        w2 = 0.35 if "GPS_RF" in (n2, n1) else 0.40
        add_track(board, (feed[0], feed[1]), (p1[0], p1[1]), w1, pcbnew.F_Cu, p1[2].GetNetCode())
        add_track(board, (p2[0], p2[1]), (rf[0], rf[1]), w2, pcbnew.F_Cu, p2[2].GetNetCode())
        print(f"  GPS RF hand-routed, R8 at ({mx:.2f},{my:.2f}) ang {ang:.1f}")


def route_usb_pair(board):
    """Hand-aim USB_DP / USB_DM as a 0.25/0.25 mm pair from U1 to J2.

    Uses the grid router on a reserved mid-right alley (east of U2, west
    of the leftover connectors) so the pair stays on F.Cu when possible.
    """
    u1 = find_fp(board, "U1")
    j2 = find_fp(board, "J2")
    if not u1 or not j2:
        print("  WARN: USB pair skipped, missing U1/J2")
        return
    dp_u = pad_world(u1, "14")
    dm_u = pad_world(u1, "13")
    # J2 has two pads per net (A and B). Use the north-most (smaller Y) SMT row.
    def best_j2(net):
        cands = []
        for p in j2.Pads():
            if p.GetNetname() == net:
                pos = p.GetPosition()
                cands.append((to_mm(pos.y), to_mm(pos.x), p))
        if not cands:
            return None
        cands.sort()  # smallest Y = farther from the shell / closer to the board
        return cands[0][1], cands[0][0], cands[0][2]
    dp_j = best_j2("USB_DP")
    dm_j = best_j2("USB_DM")
    if not (dp_u and dm_u and dp_j and dm_j):
        print("  WARN: USB pads missing", bool(dp_u), bool(dm_u), bool(dp_j), bool(dm_j))
        return
    router = GridRouter(board, pitch=0.10, clearance=0.22)
    ok = 0
    for a, b, net in (
        ((dp_u[0], dp_u[1]), (dp_j[0], dp_j[1]), "USB_DP"),
        ((dm_u[0], dm_u[1]), (dm_j[0], dm_j[1]), "USB_DM"),
    ):
        n = ensure_net(board, net)
        if router.route(a, b, n.GetNetCode(), 0.25, allow_via=True):
            ok += 1
        else:
            print(f"  WARN: could not grid-route {net}")
    print(f"  USB pair routed {ok}/2 (0.25 mm, target gap 0.25 mm; verify in Pcbnew)")


def route_grid_signals(board):
    """Careful first-pass A* on F/B for remaining short-to-medium nets.

    GND is left to the planes. GPS RF is already hand-routed. Failed
    nets stay as ratsnest — we never keep a route the router could not
    finish, so a short from a half-written path is not added.
    """
    nets = collect_pads_by_net(board)
    skip = {"GND", "", "USB_DP", "USB_DM"}
    # unique pad positions per net (ignore stacked pads)
    jobs = []
    for name, pads in nets.items():
        if name in skip or name.startswith("unconnected"):
            continue
        # unique points
        pts = []
        seen = set()
        for p in pads:
            key = (round(p["x"], 3), round(p["y"], 3))
            if key in seen:
                continue
            seen.add(key)
            pts.append((p["x"], p["y"]))
        if len(pts) < 2:
            continue
        # MST edges
        used = {0}
        edges = []
        while len(used) < len(pts):
            best = None
            for i in used:
                for j, q in enumerate(pts):
                    if j in used:
                        continue
                    d = math.hypot(pts[i][0] - q[0], pts[i][1] - q[1])
                    if best is None or d < best[0]:
                        best = (d, i, j)
            if best is None:
                break
            _, i, j = best
            edges.append((pts[i], pts[j], best[0]))
            used.add(j)
        width = netclass_width(board, name)
        # Skip very long power first-pass edges that would wander; planes help those.
        max_len = 55.0 if width <= 0.30 else 35.0
        for a, b, d in edges:
            if d < 0.12:
                continue
            if d > max_len:
                continue
            jobs.append((d, name, a, b, width))
    jobs.sort()  # short first
    router = GridRouter(board, pitch=0.10, clearance=0.22)
    ok = fail = 0
    for d, name, a, b, width in jobs:
        n = ensure_net(board, name)
        if router.route(a, b, n.GetNetCode(), width, allow_via=True):
            ok += 1
        else:
            fail += 1
    print(f"  grid-routed {ok} segments, {fail} left as ratsnest")
    return ok, fail


def route_all(board):
    """Inspection routing: GPS RF is hand-routed. USB is grid-routed as
    a pair. Short decoupling stubs and a conservative 2-layer A* pass
    cover as many remaining nets as will fit without inventing shorts.
    Anything the router cannot finish is left as ratsnest.
    """
    route_specials(board)
    try:
        route_usb_pair(board)
    except Exception as exc:
        print(f"  USB pair failed: {type(exc).__name__}: {exc}")
    nets = collect_pads_by_net(board)
    # Build a list of pad obstacles
    obstacles = []
    for fp in board.GetFootprints():
        for p in fp.Pads():
            pos = p.GetPosition()
            size = p.GetSize()
            obstacles.append((to_mm(pos.x), to_mm(pos.y),
                              max(to_mm(size.x), to_mm(size.y)) / 2, p.GetNetname()))

    def segment_hits(a, b, netname, ignore):
        ax, ay = a; bx, by = b
        length = math.hypot(bx - ax, by - ay) or 1
        for i in range(int(length / 0.1) + 1):
            t = i / (int(length / 0.1) or 1)
            x = ax + t * (bx - ax)
            y = ay + t * (by - ay)
            for cx, cy, r, n in obstacles:
                if n == netname:
                    continue
                if (cx, cy) in ignore:
                    continue
                if math.hypot(x - cx, y - cy) < r + 0.25:
                    return True
        return False

    ok = fail = 0
    jobs = 0
    for name, pads in nets.items():
        if name in ("GND", "") or name.startswith("unconnected"):
            continue
        if len(pads) < 2:
            continue
        # only very local 2-pin connections
        for i, p in enumerate(pads):
            for q in pads[i + 1:]:
                d = math.hypot(p["x"] - q["x"], p["y"] - q["y"])
                if d < 0.15 or d > 2.2:
                    continue
                # prefer colinear-ish
                jobs += 1
                a = (p["x"], p["y"]); b = (q["x"], q["y"])
                if segment_hits(a, b, name, {(p["x"], p["y"]), (q["x"], q["y"])}):
                    fail += 1
                    continue
                n = ensure_net(board, name)
                add_track(board, a, b, netclass_width(board, name), pcbnew.F_Cu, n.GetNetCode())
                ok += 1
    print(f"  local stubs ok={ok} skipped={fail} considered={jobs}")
    # A full 2-layer A* pass was tried and produced large numbers of
    # shorts and clearance errors. For this inspection board we keep
    # the hand-routed GPS RF, the USB pair, and local stubs only, and
    # leave the rest as ratsnest rather than ship shorted copper.
    # try:
    #     route_grid_signals(board)
    # except Exception as exc:
    #     print(f"  grid signal pass failed: {type(exc).__name__}: {exc}")
    return ok, fail, jobs


def add_zones(board):
    def outline_pts():
        # slightly inset from the edge
        inset = 0.30
        return [
            (inset, inset),
            (W - inset, inset),
            (W - inset, H - inset),
            (inset, H - inset),
        ]

    def make_zone(netname, layer, minw=0.20, clr=0.20, priority=0):
        n = ensure_net(board, netname)
        z = pcbnew.ZONE(board)
        z.SetNetCode(n.GetNetCode())
        z.SetLayer(layer)
        z.SetLocalClearance(mm(clr))
        z.SetMinThickness(mm(minw))
        if hasattr(z, "SetAssignedPriority"):
            z.SetAssignedPriority(priority)
        elif hasattr(z, "SetPriority"):
            z.SetPriority(priority)
        z.SetPadConnection(pcbnew.ZONE_CONNECTION_THERMAL)
        z.SetThermalReliefGap(mm(0.20))
        z.SetThermalReliefSpokeWidth(mm(0.30))
        z.Outline().NewOutline()
        for x, y in outline_pts():
            z.Outline().Append(mm(x), mm(y))
        # punch the USB notch out roughly by a hole? not critical if notch is outside
        board.Add(z)
        return z

    # F.Cu GND (priority low), In1 solid GND, In2 GND + 3V3/5V/BAT islands later as full pours,
    # B.Cu GND
    # Ground planes only. Do not pour +3V3 / +5V / BAT as full-board
    # zones on the same layer — they would short one another.
    make_zone("GND", pcbnew.F_Cu, priority=0)
    make_zone("GND", pcbnew.In1_Cu, priority=0)
    make_zone("GND", pcbnew.In2_Cu, priority=0)
    make_zone("GND", pcbnew.B_Cu, priority=0)
    print("  filling zones...")
    filler = pcbnew.ZONE_FILLER(board)
    filler.Fill(board.Zones())
    print("  zones filled")


def add_board_silk(board):
    add_silk_text(board, "DriveTrack V5S", 26.0, 68.15, size=0.9, thick=0.12)
    add_silk_text(board, "52x70 4L STACK", 10.5, 68.15, size=0.7, thick=0.10)
    # Vehicle axes: FRONT = y=0, USB is aft. Same convention as the slim V5.
    ax, ay = 26.0, 34.0
    add_silk_line(board, (ax, ay + 3.2), (ax, ay - 3.2), 0.15)
    add_silk_line(board, (ax, ay - 3.2), (ax - 0.7, ay - 2.3), 0.15)
    add_silk_line(board, (ax, ay - 3.2), (ax + 0.7, ay - 2.3), 0.15)
    add_silk_text(board, "VEH +X FWD", ax + 4.6, ay - 2.6, size=0.7, thick=0.10)
    add_silk_line(board, (ax, ay), (ax + 3.2, ay), 0.15)
    add_silk_line(board, (ax + 3.2, ay), (ax + 2.3, ay - 0.7), 0.15)
    add_silk_line(board, (ax + 3.2, ay), (ax + 2.3, ay + 0.7), 0.15)
    add_silk_text(board, "VEH +Y", ax + 5.0, ay + 1.4, size=0.7, thick=0.10)
    add_silk_text(board, "VEH +Z UP", ax + 4.6, ay + 2.6, size=0.7, thick=0.10)
    add_silk_text(board, "FRONT", 26.0, 1.15, size=0.8, thick=0.12)
    # GPS keepout outline
    gx, gy = ANT1_XY
    add_silk_rect(board, (gx - 12.7, gy - 12.7), (gx + 12.7, gy + 12.7), 0.12)
    add_silk_text(board, "GPS 25x25", gx, gy - 13.6, size=0.7, thick=0.10)
    # LED labels
    names = ["<25", "25-50", "50-75", "75-100", "STAT"]
    for x, n in zip(LED_XS, names):
        add_silk_text(board, n, x, 1.35, size=0.6, thick=0.09)
    # BMI088 note
    add_silk_text(board, "U3 BMI088", U3_XY[0], U3_XY[1] - 2.6, size=0.6, thick=0.09)
    # Cell outline on both silk and comments — posts must stay outside
    add_silk_rect(board, (CELL_X0 + 0.3, CELL_Y0 + 0.3), (CELL_X1 - 0.3, CELL_Y1 - 0.3),
                  0.12, layer=pcbnew.B_SilkS)
    add_silk_text(board, "CELL 104060 UNDER", 20.0, 8.0, size=0.8, thick=0.12,
                  layer=pcbnew.B_SilkS)
    add_silk_text(board, "NO POSTS THROUGH POUCH", 20.0, 9.6, size=0.7, thick=0.10,
                  layer=pcbnew.B_SilkS)
    add_silk_rect(board, (CELL_X0, CELL_Y0), (CELL_X1, CELL_Y1), 0.10, layer=pcbnew.Cmts_User)
    add_silk_text(board, "CELL BAY 40x60  X=0..40  Y=2..62  leftover X=40..52",
                  26.0, CELL_Y1 + 1.2, size=0.6, thick=0.08, layer=pcbnew.Cmts_User)
    # 2.4G FPC lid keepout (comment layer), not over the patch
    add_silk_rect(board, (33.0, 28.0), (50.0, 64.4), 0.10, layer=pcbnew.Cmts_User)
    add_silk_text(board, "LID: 2.4G FPC 34x12 — not over patch", 41.0, 27.0,
                  size=0.6, thick=0.08, layer=pcbnew.Cmts_User)
    add_silk_text(board, "KEY pads / USB wake  |  no panel switch", 26.0, 69.15,
                  size=0.6, thick=0.09)
    add_silk_text(board, "J3 fold down to cell", 41.5, 61.2, size=0.6, thick=0.09)


def add_dimension_notes_on_cmts(board):
    add_silk_text(board, "MH1 46.40,3.50  MH2 46.40,66.50  MH3 3.20,66.50  MH4 36.40,66.50  NPTH 2.2  (outside cell)",
                  26.0, -2.2, size=0.7, thick=0.10, layer=pcbnew.Cmts_User)
    add_silk_text(board, "J2 USB origin 26.00,64.77  notch floor y=65.50  w=9.20",
                  26.0, -3.4, size=0.7, thick=0.10, layer=pcbnew.Cmts_User)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    template = os.path.join(PROJ, "drivetrack-pcb-v5.stripped.kicad_pcb")
    print("Loading stripped template", template)
    board = pcbnew.LoadBoard(template)
    board.SetFileName(BOARD_PATH)

    print("Removing retired footprints J6 J7 J8 Q2 R25")
    for ref in ("J6", "J7", "J8", "Q2", "R25"):
        if delete_fp(board, ref):
            print("  removed", ref)

    print("Outline")
    build_outline(board)

    print("Mounting holes")
    replace_mounting_holes(board)

    print("Placing major parts")
    place_existing(board, "ANT1", *ANT1_XY, 0)
    place_existing(board, "U1", *U1_XY, U1_ROT)
    place_existing(board, "U3", *U3_XY, U3_ROT)
    place_existing(board, "U4", *U4_XY, U4_ROT)
    place_existing(board, "U5", *U5_XY, U5_ROT)
    place_existing(board, "U6", *U6_XY, U6_ROT)
    place_existing(board, "L1", *L1_XY, L1_ROT)
    place_existing(board, "L2", *L2_XY, L2_ROT)
    place_existing(board, "J2", *J2_XY, J2_ROT)
    place_u2_for_short_rf(board)
    place_j1_j3(board)

    # Assign new U1 nets
    u1 = find_fp(board, "U1")
    assign_pad_net(u1, "34", board, "KEY_CTRL")   # IO41
    assign_pad_net(u1, "35", board, "VBUS_DET")   # IO42

    # Compact BOOT/RST
    for ref, pos, net in (("SW1", SW1_XY, "BOOT"), ("SW2", SW2_XY, "EN")):
        delete_fp(board, ref)
        add_fp(board, "Button_Switch_SMD:SW_SPST_EVQP7A", ref,
               "BOOT" if ref == "SW1" else "RST",
               pos[0], pos[1], 0,
               {"1": net, "2": "GND"})

    # Test points: a row in the USB-end keep-out, west of the receptacle,
    # plus GPS_PPS near U2. All clear of MH3/MH4.
    tp_pos = {
        "TP1": ((5.80, 63.20), "+3V3"),
        "TP2": ((8.20, 63.20), "GND"),
        "TP4": ((10.60, 63.20), "BAT"),
        "TP5": ((13.00, 63.20), "VBAT_DIV"),
        "TP6": ((15.40, 63.20), "UART0_TX"),
        "TP7": ((17.80, 63.20), "UART0_RX"),
        "TP8": ((20.20, 63.20), "IO2"),
        "TP3": ((6.00, 36.00), "GPS_PPS"),
    }
    for ref, (pos, net) in tp_pos.items():
        delete_fp(board, ref)
        add_fp(board, "TestPoint:TestPoint_Pad_D1.5mm", ref, f"TP {net}",
               pos[0], pos[1], 0, {"1": net})

    # J5 rescue UART as four 1.0 mm pads (DNI header no longer used)
    if find_fp(board, "J5"):
        delete_fp(board, "J5")
    j5_nets = [("J5A", "UART0_TX"), ("J5B", "UART0_RX"), ("J5C", "+3V3"), ("J5D", "GND")]
    for i, (ref, net) in enumerate(j5_nets):
        add_fp(board, "TestPoint:TestPoint_Pad_D1.0mm", ref, net,
               4.4 + i * 2.0, 44.0, 0, {"1": net})

    # LEDs
    led_nets = ["LED1", "LED2", "LED3", "LED4", "STAT_ANODE"]
    for i, (x, net) in enumerate(zip(LED_XS, led_nets), start=1):
        add_fp(board, "LED_SMD:LED_0805_2012Metric", f"DS{i}", "LED 0805",
               x, LED_Y, 0, {"1": "GND", "2": net})

    # Rewire R26: STAT_LED -- R26 -- STAT_ANODE
    r26 = find_fp(board, "R26")
    if r26:
        set_fp_at(r26, 33.4, 5.10, 0)
        assign_pad_net(r26, "1", board, "STAT_ANODE")
        assign_pad_net(r26, "2", board, "STAT_LED")

    # R32 already IO2/LED4 — park near DS4
    r32 = find_fp(board, "R32")
    if r32:
        set_fp_at(r32, 30.6, 5.10, 0)

    # KEY pads and MCU KEY FET in the leftover strip, south of U1
    add_fp(board, "TestPoint:TestPoint_Pad_D1.5mm", "TP9", "TP KEY",
           44.00, 33.40, 0, {"1": "KEY"})
    add_fp(board, "TestPoint:TestPoint_Pad_D1.5mm", "TP10", "TP KEY_GND",
           46.20, 33.40, 0, {"1": "GND"})

    add_fp(board, "Package_TO_SOT_SMD:SOT-23", "Q3", "2N7002",
           44.00, 31.00, 0, {"1": "KEY_GATE", "2": "GND", "3": "KEY"})
    add_fp(board, "Resistor_SMD:R_0603_1608Metric", "R33", "1k",
           48.50, 31.20, 0, {"1": "KEY_CTRL", "2": "KEY_GATE"})

    # VBUS divider between U5 and the USB keep-out, west of the receptacle
    add_fp(board, "Resistor_SMD:R_0603_1608Metric", "R35", "100k",
           5.60, 60.80, 0, {"1": "VBUS", "2": "VBUS_DET"})
    add_fp(board, "Resistor_SMD:R_0603_1608Metric", "R36", "100k",
           7.60, 60.80, 0, {"1": "VBUS_DET", "2": "GND"})
    add_fp(board, "Capacitor_SMD:C_0603_1608Metric", "C26", "100n",
           5.60, 59.00, 0, {"1": "VBUS_DET", "2": "GND"})

    # Park DNI parts off the ceramic antenna and off U1
    place_existing(board, "U7", 46.00, 29.60, 0)          # SK6812 DNI, leftover
    place_existing(board, "J4", 47.20, 31.20, 0)          # U.FL DNI
    if find_fp(board, "J9"):
        place_existing(board, "J9", 46.50, 39.20, 90)    # DNI solder pads, leftover

    # Power passives near U5 / L1 / U6
    place_passives_near(board, ["C16", "C18", "C24", "C25", "R4", "R27"], 7.5, 53.0, cols=3, pitch=1.9)
    place_passives_near(board, ["C19", "C20", "C21", "C22", "C23", "R22", "R23", "R24"], 21.0, 49.0, cols=4, pitch=2.1)
    place_passives_near(board, ["Q1", "R19", "R20", "R21"], 16.0, 50.6, cols=2, pitch=1.9)
    # IMU / baro / GPS passives
    place_passives_near(board, ["C4", "C10", "C11", "R9", "R10"], 24.0, 49.2, cols=3, pitch=1.8)
    place_passives_near(board, ["C8", "C9", "C12", "R11", "R12"], 7.6, 47.0, cols=3, pitch=1.7)
    place_passives_near(board, ["C5", "C6", "C7", "FB1", "R5", "R6", "R7"], 22.0, 36.5, cols=4, pitch=2.0)
    # ESP decoupling in the leftover strip, south of U1
    place_passives_near(board, ["C1", "C2", "C13", "C15", "R1", "R2", "R3"], 43.4, 28.6, cols=2, pitch=1.8)
    # microSD passives (final J1 location is nearby; packer will nudge)
    place_passives_near(board, ["C14", "R13", "R14", "R15"], 33.0, 40.0, cols=2, pitch=1.8)
    # USB ESD / CC, east of the receptacle, west of MH4
    place_passives_near(board, ["D1", "D2", "D3", "R16", "R17", "R18"], 32.4, 60.2, cols=3, pitch=2.0)
    place_passives_near(board, ["R30", "R31"], 22.0, 48.0, cols=2, pitch=1.8)
    # leftovers: anything not moved still sits at V4.5 coordinates — pull them in
    placed_ok = set()
    for fp in board.GetFootprints():
        x, y = to_mm(fp.GetPosition().x), to_mm(fp.GetPosition().y)
        if 0 <= x <= W and 0 <= y <= H:
            placed_ok.add(fp.GetReference())
    leftovers = []
    for fp in board.GetFootprints():
        ref = fp.GetReference()
        x, y = to_mm(fp.GetPosition().x), to_mm(fp.GetPosition().y)
        if x < -1 or y < -1 or x > W + 3 or y > H + 3:
            leftovers.append(ref)
    print("  leftovers outside the new board:", leftovers)
    # dump leftovers into a spare strip along the west edge under the LEDs / east of BMP
    place_passives_near(board, leftovers, 8.0, 42.6, cols=4, pitch=1.8)


    placed, extra = place_passives_manual(board)
    print(f"  manual passives {placed}, extra {extra}")

    print("Collision report (after placement)")
    report_collisions(board)


    print("Silk / keepouts / notes")
    add_board_silk(board)
    add_dimension_notes_on_cmts(board)
    # F.Cu keepout over the ceramic patch except we still need the feed — allow pours off, block stray tracks
    ax, ay = ANT1_XY
    # Silk already outlines the patch. A copper keepout here would also
    # block the 50 ohm feed, so it is not a rule area.

    print("Routing")
    route_all(board)

    print("Zones")
    add_zones(board)

    # title / properties
    if hasattr(board, "GetTitleBlock"):
        tb = board.GetTitleBlock()
        tb.SetTitle("DriveTrack Custom PCB V5 stacked")
        tb.SetRevision("5.1")
        tb.SetDate("2026-11-17")
        tb.SetComment(0, "52 x 70 mm, 4-layer, cell under PCB, inspection layout")

    print("Saving", BOARD_PATH)
    pcbnew.SaveBoard(BOARD_PATH, board)
    print("Done.")


if __name__ == "__main__":
    main()
