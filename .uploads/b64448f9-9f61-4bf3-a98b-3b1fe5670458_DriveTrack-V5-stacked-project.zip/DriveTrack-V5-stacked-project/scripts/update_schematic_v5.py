#!/usr/bin/env python3
"""Update the copied V4.5 schematic to DriveTrack PCB V5.

Changes are documented in CHANGELOG-V5.md / DESIGN-NOTES-V5.md.
This script is idempotent enough to re-run on the original copy only;
it expects a V4.5-format schematic.
"""
from __future__ import annotations

import re
import uuid
from pathlib import Path

SCH = Path("/workspace/drivetrack-pcb-v5/DriveTrack-PCB-V5/drivetrack-pcb-v5.kicad_sch")


def uid() -> str:
    return str(uuid.uuid4())


def symbol_block(lib_id, ref, value, footprint, at, pins, dnp="no", in_bom="yes", on_board="yes", rot=0):
    x, y = at
    pin_s = "\n".join(
        f'  (pin\n   "{p}"\n   (uuid "{uid()}"))' for p in pins
    )
    return f""" (symbol
  (lib_id {lib_id})
  (at {x} {y} {rot})
  (unit 1)
  (in_bom {in_bom})
  (on_board {on_board})
  (dnp {dnp})
  (uuid "{uid()}")
  (property
   Reference
   {ref}
   (at {x} {y + 8} 0)
   (effects
    (font
     (size 1.27 1.27))))
  (property
   Value
   {value}
   (at {x} {y - 8} 0)
   (effects
    (font
     (size 1.27 1.27))))
  (property
   Footprint
   {footprint}
   (at 0 0 0)
   (effects
    (font
     (size 1.27 1.27))
    hide))
  (property
   Datasheet
   "~"
   (at 0 0 0)
   (effects
    (font
     (size 1.27 1.27))
    hide))
{pin_s}
  (instances
   (project
    drivetrack-pcb-v5
    (path
     "/b98751ef-f742-4dbe-bc7d-7dddb865b2d3"
     (reference {ref})
     (unit 1)))))
"""


def label(name, at, angle=0, shape="input"):
    x, y = at
    # justify: KiCad wants left, rotation handles side
    return f""" (global_label
  {name}
  (shape {shape})
  (at {x} {y} {angle})
  (effects
   (font
    (size 1.27 1.27))
   (justify left))
  (uuid "{uid()}"))
"""


def wire(a, b):
    x1, y1 = a
    x2, y2 = b
    return f""" (wire
  (pts
   (xy {x1} {y1})
   (xy {x2} {y2}))
  (stroke
   (width 0)
   (type solid))
  (uuid "{uid()}"))
"""


def pwr(lib, value, at, ref):
    x, y = at
    return f""" (symbol
  (lib_id {lib})
  (at {x} {y} 0)
  (unit 1)
  (in_bom no)
  (on_board yes)
  (dnp no)
  (uuid "{uid()}")
  (property
   Reference
   {ref}
   (at {x} {y} 0)
   (effects
    (font
     (size 1.27 1.27))
    hide))
  (property
   Value
   {value}
   (at {x} {y} 0)
   (effects
    (font
     (size 1.27 1.27))
    hide))
  (property
   Footprint
   ""
   (at 0 0 0)
   (effects
    (font
     (size 1.27 1.27))
    hide))
  (property
   Datasheet
   "~"
   (at 0 0 0)
   (effects
    (font
     (size 1.27 1.27))
    hide))
  (pin
   "1"
   (uuid "{uid()}"))
  (instances
   (project
    drivetrack-pcb-v5
    (path
     "/b98751ef-f742-4dbe-bc7d-7dddb865b2d3"
     (reference {ref})
     (unit 1)))))
"""


def text(s, at, size=1.27):
    x, y = at
    return f""" (text
  "{s}"
  (at {x} {y} 0)
  (effects
   (font
    (size {size} {size})))
  (uuid "{uid()}"))
"""


def delete_symbol_by_ref(src: str, ref: str) -> str:
    """Delete a top-level (symbol ...) instance whose Reference is ref."""
    # Find `(property\n   Reference\n   REF\n` and walk back to `(symbol\n`
    pat = re.compile(rf"\(property\n\s+Reference\n\s+{re.escape(ref)}\n")
    m = pat.search(src)
    if not m:
        print(f"WARNING: symbol {ref} not found")
        return src
    start = src.rfind("(symbol\n", 0, m.start())
    if start < 0:
        print(f"WARNING: symbol start for {ref} not found")
        return src
    # The instance starts with a space or newline before (symbol
    # include the leading space/newline
    if start > 0 and src[start - 1] in " \n":
        # keep one newline
        pass
    depth = 0
    for j in range(start, len(src)):
        if src[j] == "(":
            depth += 1
        elif src[j] == ")":
            depth -= 1
            if depth == 0:
                end = j + 1
                break
    else:
        raise RuntimeError(f"unbalanced sexp for {ref}")
    print(f"  deleted symbol {ref} bytes {end-start}")
    return src[:start] + src[end:]


def delete_no_connect_at(src: str, x: float, y: float) -> str:
    pat = re.compile(
        r" \(no_connect\n\s+\(at\s+([0-9.eE+-]+)\s+([0-9.eE+-]+)[\s\S]*?\n\s*\)\n"
    )
    found = {"n": 0}
    def repl(m):
        if found["n"]:
            return m.group(0)
        if abs(float(m.group(1)) - x) < 0.02 and abs(float(m.group(2)) - y) < 0.02:
            found["n"] += 1
            print(f"  deleted no_connect at {m.group(1)},{m.group(2)}")
            return ""
        return m.group(0)
    src2 = pat.sub(repl, src)
    if not found["n"]:
        print(f"WARNING: no_connect at {x},{y} not found")
    return src2


def set_prop_flag(src: str, ref: str, flag: str, value: str) -> str:
    """Set (dnp yes/no) etc. inside a symbol instance identified by Reference."""
    pat = re.compile(rf"\(property\n\s+Reference\n\s+{re.escape(ref)}\n")
    m = pat.search(src)
    if not m:
        print(f"WARNING: {ref} not found for flag {flag}")
        return src
    start = src.rfind("(symbol\n", 0, m.start())
    depth = 0
    for j in range(start, len(src)):
        if src[j] == "(":
            depth += 1
        elif src[j] == ")":
            depth -= 1
            if depth == 0:
                end = j + 1
                break
    block = src[start:end]
    block2, n = re.subn(rf"\({flag}(?:\n\s+|\s+)(\w+)\)", f"({flag} {value})", block, count=1)
    if n:
        print(f"  set {ref} {flag}={value}")
    else:
        print(f"WARNING: flag {flag} not found in {ref}")
    return src[:start] + block2 + src[end:]


def set_footprint(src: str, ref: str, new_fp: str) -> str:
    pat = re.compile(rf"\(property\n\s+Reference\n\s+{re.escape(ref)}\n")
    m = pat.search(src)
    if not m:
        print(f"WARNING: {ref} not found for footprint")
        return src
    start = src.rfind("(symbol\n", 0, m.start())
    depth = 0
    for j in range(start, len(src)):
        if src[j] == "(":
            depth += 1
        elif src[j] == ")":
            depth -= 1
            if depth == 0:
                end = j + 1
                break
    block = src[start:end]
    block2, n = re.subn(
        r"\(property\n\s+Footprint\n\s+[^\n]+",
        f"(property\n   Footprint\n   {new_fp}",
        block,
        count=1,
    )
    if n:
        print(f"  set {ref} footprint {new_fp}")
    else:
        print(f"WARNING: footprint prop not found in {ref}")
    return src[:start] + block2 + src[end:]


def _num(v: float) -> str:
    """Regex that matches a KiCad number equal to v (366 or 366.00, 59.3 or 59.30)."""
    # use a small float compare via a capturing function instead
    return f"{v}"

def delete_wire(src: str, a, b, tol=0.02) -> str:
    def near(s, v):
        try:
            return abs(float(s) - v) <= tol
        except ValueError:
            return False
    pat = re.compile(
        r" \(wire\n\s+\(pts\n\s+\(xy\s+([0-9.eE+-]+)\s+([0-9.eE+-]+)\)\n\s+\(xy\s+([0-9.eE+-]+)\s+([0-9.eE+-]+)\)[\s\S]*?uuid[^\n]+\n\s*\)\n"
    )
    def repl(m):
        x1,y1,x2,y2 = map(float, m.groups())
        if (near(x1,a[0]) and near(y1,a[1]) and near(x2,b[0]) and near(y2,b[1])) or \
           (near(x1,b[0]) and near(y1,b[1]) and near(x2,a[0]) and near(y2,a[1])):
            print(f"  deleted wire ({x1},{y1})->({x2},{y2})")
            return ""
        return m.group(0)
    src2, n = pat.subn(repl, src)
    # subn with a function that sometimes returns original still counts as sub if we always... no, we return original string, still a "sub"?
    # Actually subn counts all matches of the pattern, not only when we return "". That would delete nothing but might be slow and n wrong.
    # Use finditer + splice instead if needed. For now, only return "" for the first match and leave others.
    # Because we used subn on ALL wires, every wire is "replaced" (often with itself). That's OK as long as we only blank the target.
    found = "deleted wire" in "".join([])  # dummy
    if src2 != src:
        return src2
    print(f"WARNING: wire {a}->{b} not found")
    return src


def main():
    src = SCH.read_text()
    assert "DriveTrack Custom PCB" in src

    # Title
    src = src.replace('(rev "4.5")', '(rev "5.0")')
    src = src.replace("(date 2026-11-12)", "(date 2026-11-17)")
    src = src.replace(
        '"DriveTrack Custom PCB - Schematic (V4.5)"',
        '"DriveTrack Custom PCB - Schematic (V5 slim)"',
    )

    # Delete off-board headers that V5 no longer uses as populated connectors
    for ref in ("J6", "J7", "J8"):
        src = delete_symbol_by_ref(src, ref)

    # BOOT/RST compact tactile switch; test points become SMT pads
    src = set_footprint(src, "SW1", "Button_Switch_SMD:SW_SPST_EVQP7A")
    src = set_footprint(src, "SW2", "Button_Switch_SMD:SW_SPST_EVQP7A")
    for ref in ("TP1", "TP2", "TP3", "TP4", "TP5", "TP6", "TP7", "TP8"):
        src = set_footprint(src, ref, "TestPoint:TestPoint_Pad_D1.5mm")

    # Q2 / R25 no longer in the status-LED path (direct GPIO drive like LED4)
    src = set_prop_flag(src, "Q2", "dnp", "yes")
    src = set_prop_flag(src, "Q2", "in_bom", "no")
    src = set_prop_flag(src, "Q2", "on_board", "no")
    src = set_prop_flag(src, "R25", "dnp", "yes")
    src = set_prop_flag(src, "R25", "in_bom", "no")
    src = set_prop_flag(src, "R25", "on_board", "no")

    # Disconnect R26 from Q2 collector / J7 anode node
    # R26 top was at 366,268.19 -> 366,262 -> 369.84,262 (J7-1)
    # R26 bottom 366,275.81 -> 366,278 -> 346.54,278 (Q2-C)
    src = delete_wire(src, (366.00, 268.19), (366.00, 262.00))
    src = delete_wire(src, (366.00, 262.00), (369.84, 262.00))
    src = delete_wire(src, (374.92, 262.00), (369.84, 262.00))
    src = delete_wire(src, (366.00, 275.81), (366.00, 278.00))
    src = delete_wire(src, (346.54, 278.00), (366.00, 278.00))

    # Remove no-connects on U1 IO41 and IO42 (right side of U1)
    src = delete_no_connect_at(src, 108.32, 61.84)  # IO41
    src = delete_no_connect_at(src, 108.32, 59.30)  # IO42

    # ---- New circuitry, placed on the free right side of the A3 sheet ----
    # Origin of the V5 addition block: x=430..520, y=30..200 (LEDs + KEY + VBUS)
    parts = []
    parts.append(text("J - V5 slim: on-board LEDs, KEY pads, USB wake", (430, 24), 1.52))
    parts.append(text("4 gauge + 1 status are SMT 0805 under the lid window.", (430, 28), 1.0))
    parts.append(text("No panel key. Hard-off wake = insert USB-C (VBUS).", (430, 32), 1.0))
    parts.append(text("Daily wake = App / IMU. MCU can pulse KEY (Q3).", (430, 36), 1.0))

    # DS1-DS4 gauge LEDs, DS5 status. Device:LED pin1=K pin2=A. Horizontal.
    # LED symbol pins: K at -3.81, A at +3.81 when rot=0.
    led_y0 = 50
    led_defs = [
        ("DS1", "LED1", "gauge <25%", 50),
        ("DS2", "LED2", "gauge 25-50%", 64),
        ("DS3", "LED3", "gauge 50-75%", 78),
        ("DS4", "LED4", "gauge 75-100%", 92),
        ("DS5", "STAT_ANODE", "status", 106),
    ]
    for ref, anode_net, note, y in led_defs:
        cx, cy = 460, y
        parts.append(
            symbol_block(
                "Device:LED",
                ref,
                "LED 0805",
                "LED_SMD:LED_0805_2012Metric",
                (cx, cy),
                ["1", "2"],
            )
        )
        # A (right, +3.81) to anode net; K (left, -3.81) to GND
        parts.append(wire((cx + 3.81, cy), (cx + 8, cy)))
        parts.append(label(anode_net, (cx + 8, cy), angle=0))
        parts.append(wire((cx - 3.81, cy), (cx - 8, cy)))
        parts.append(label("GND", (cx - 8, cy), angle=180))
        parts.append(text(note, (cx + 14, cy), 1.0))

    # R26 now series for DS5: STAT_LED (GPIO) --R26-- STAT_ANODE
    # Place a fresh connection using the existing R26 symbol (still at 366,272)
    # Add labels on the now-open R26 pins.
    parts.append(label("STAT_ANODE", (366.00, 268.19), angle=90))
    parts.append(label("STAT_LED", (366.00, 275.81), angle=270))
    parts.append(text("R26 = 330R series for DS5 (direct GPIO drive)", (300, 286), 1.0))
    parts.append(text("Q2 / R25 DNP: previous transistor drive removed in V5", (300, 290), 1.0))

    # R32 already goes IO2 --R32-- LED4; DS4 anode is LED4. Good.

    # KEY test pads TP9 (KEY) TP10 (GND)
    parts.append(
        symbol_block(
            "Connector_Generic:Conn_01x01",
            "TP9",
            "TP KEY",
            "TestPoint:TestPoint_Pad_D1.5mm",
            (460, 130),
            ["1"],
        )
    )
    parts.append(wire((454.92, 130), (448, 130)))
    parts.append(label("KEY", (448, 130), angle=180))
    parts.append(
        symbol_block(
            "Connector_Generic:Conn_01x01",
            "TP10",
            "TP KEY_GND",
            "TestPoint:TestPoint_Pad_D1.5mm",
            (460, 140),
            ["1"],
        )
    )
    parts.append(wire((454.92, 140), (448, 140)))
    parts.append(label("GND", (448, 140), angle=180))
    parts.append(text("KEY test pads only (production test). No panel switch.", (430, 148), 1.0))

    # Q3 2N7002 MCU KEY control: KEY_CTRL --R33 1k-- G, S=GND, D=KEY
    # Place Q3 at (460, 170). 2N7002 symbol typically G left, D/S right - use labels on all pins via short wires.
    # We don't rely on exact pin coords of 2N7002; place labels with short stubs after checking.
    # Standard KiCad Transistor_FET:2N7002 (unit at origin):
    # Often G at (-5.08, 0), D at (5.08, 2.54), S at (5.08, -2.54) — will add labels at those points.
    parts.append(
        symbol_block(
            "Transistor_FET:2N7002",
            "Q3",
            "2N7002",
            "Package_TO_SOT_SMD:SOT-23",
            (470, 170),
            ["1", "2", "3"],
        )
    )
    parts.append(
        symbol_block(
            "Device:R",
            "R33",
            "1k",
            "Resistor_SMD:R_0603_1608Metric",
            (445, 170),
            ["1", "2"],
        )
    )
    # R vertical or horizontal? Device:R pins at (0,3.81) and (0,-3.81) — vertical.
    # Rotate R33 90 so it's horizontal: rot=90, pins at +/-3.81 in X.
    # Recreate R33 with rot 90 — the symbol_block already wrote rot 0. Patch by writing a custom one.
    # I'll add wires assuming R33 is vertical at (445,170): pins (445,173.81) and (445,166.19)
    # That's awkward for KEY_CTRL. Put R33 horizontal by rot=90.
    # Instead of editing the just-added block, add wires from those pins to labels with elbows.

    # KEY_CTRL label to R33 top, R33 bottom to Q3 gate.
    # Q3 at (470,170): assume G=(-5.08)+470=464.92, y=170; D=475.08,172.54; S=475.08,167.46
    parts.append(label("KEY_CTRL", (445, 178), angle=90))
    parts.append(wire((445, 173.81), (445, 178)))
    parts.append(wire((445, 166.19), (445, 164)))
    parts.append(wire((445, 164), (464.92, 164)))
    parts.append(wire((464.92, 164), (464.92, 170)))
    parts.append(label("KEY", (480, 172.54), angle=0))
    parts.append(wire((475.08, 172.54), (480, 172.54)))
    parts.append(label("GND", (480, 167.46), angle=0))
    parts.append(wire((475.08, 167.46), (480, 167.46)))
    parts.append(text("Q3: MCU open-drain pulse of IP5306 KEY (IO41 = KEY_CTRL)", (430, 184), 1.0))
    parts.append(text("Short pulse = KEY press; >2 s low = hard-off (see notes).", (430, 188), 1.0))

    # VBUS detect divider R35/R36 100k/100k, C26 100n, to VBUS_DET (IO42)
    # VBUS -- R35 -- VBUS_DET -- R36 -- GND, C26 from VBUS_DET to GND
    parts.append(
        symbol_block(
            "Device:R",
            "R35",
            "100k",
            "Resistor_SMD:R_0603_1608Metric",
            (445, 210),
            ["1", "2"],
        )
    )
    parts.append(
        symbol_block(
            "Device:R",
            "R36",
            "100k",
            "Resistor_SMD:R_0603_1608Metric",
            (445, 230),
            ["1", "2"],
        )
    )
    parts.append(
        symbol_block(
            "Device:C",
            "C26",
            "100n",
            "Capacitor_SMD:C_0603_1608Metric",
            (470, 230),
            ["1", "2"],
        )
    )
    # R35 top (445,213.81) = VBUS, bottom (445,206.19) wait: at y=210, pin+ = 210+3.81=213.81, pin- = 206.19
    # Device:R pin 1 is typically at +3.81 (up). Chain: VBUS at top of R35, mid node at bottom of R35 / top of R36.
    parts.append(label("VBUS", (445, 218.5), angle=90))
    parts.append(wire((445, 213.81), (445, 218.5)))
    # mid node y ~ 206.19 (R35 bot) to R36 top 230+3.81=233.81 — gap, need a longer drop.
    # R36 is at 230, top 233.81 is BELOW R35 bottom 206.19? In schematic Y-up, 230 is above 210!
    # I placed R36 at y=230 which is ABOVE R35 at 210. Swap: put R36 lower at y=196? 
    # In eeschema Y increases up, so y=230 is above y=210. That's the wrong order visually.
    # Leave it: I'll wire mid node horizontally.
    # Actually let me wire:
    # R35 (445,210): pin+ 213.81 VBUS, pin- 206.19 mid
    # R36 should be below R35, so y should be less than 210, e.g. I set 230 which is above. Oops.
    # Wire R36 as the bottom resistor anyway: use mid at 206.19 going down... can't reach R36 at 230 without crossing up.
    # I'll add an explicit mid label VBUS_DET and connect both resistors and C26 to it.
    parts.append(label("VBUS_DET", (455, 206.19), angle=0))
    parts.append(wire((445, 206.19), (455, 206.19)))
    # R36: connect one pin to VBUS_DET, one to GND. R36 at (445,230): pins 233.81 and 226.19
    # Wire 445,226.19 down/around to 455,206.19? Messy. Add second VBUS_DET label on R36 pin and GND on the other.
    parts.append(label("VBUS_DET", (455, 226.19), angle=0))
    parts.append(wire((445, 226.19), (455, 226.19)))
    parts.append(label("GND", (445, 238), angle=90))
    parts.append(wire((445, 233.81), (445, 238)))
    # Wait if pin+ is 233.81 (upper) and I put GND there, the divider is upside down: VBUS--R35--DET, and R36 upper is GND, lower is DET. That's still a valid divider (R36 between DET and GND). Good.
    # C26 at (470,230): Device:C pins typically +/- 3.81 in X if rot 0? Device:C is often horizontal, pins at +/-3.81 on X? 
    # Device:C pins: pin1 (-3.81? or 0,3.81). In KiCad Device:C, pins are at (-1.508, 0) wait...
    # Standard Device:C is horizontal: pin 1 at (-2.54,0) or similar? Actually Device:C pins at (-3.81,0) and (3.81,0).
    # I'll put VBUS_DET on left and GND on right of C26, plus a note if ERC complains.
    parts.append(label("VBUS_DET", (462, 230), angle=180))
    parts.append(wire((466.19, 230), (462, 230)))  # guess; Device:C pin at x+/-1.524 or 3.81
    parts.append(label("GND", (478, 230), angle=0))
    parts.append(wire((473.81, 230), (478, 230)))
    parts.append(text("VBUS_DET = VBUS * 1/2 (100k/100k) to IO42; C26 debounce.", (430, 248), 1.0))
    parts.append(text("IP5306 enables SYS when VIN/VBUS is applied (see notes).", (430, 252), 1.0))

    # U1 IO41 / IO42 labels at the pin tips (replacing no-connects)
    parts.append(label("KEY_CTRL", (114, 61.84), angle=0))
    parts.append(wire((108.32, 61.84), (114, 61.84)))
    parts.append(label("VBUS_DET", (114, 59.30), angle=0))
    parts.append(wire((108.32, 59.30), (114, 59.30)))

    # Power-state notes near IP5306 block
    parts.append(text("Power states: HARD-OFF = SYS down, wake by inserting USB-C.", (14.54, 278), 1.0))
    parts.append(text("SLEEP = low-power, wake by App or IMU. App can command hard-off via Q3.", (14.54, 282), 1.0))
    parts.append(text("V5: no panel key, no J6/J7/J8 headers. LEDs are on-board SMT.", (14.54, 286), 1.0))

    # Update a few outdated notes if present
    src = src.replace(
        "Status LED: off-board, anode J7-1,",
        "Status LED: on-board SMT DS5, anode STAT_ANODE,",
    )
    src = src.replace(
        "cathode J7-2 (GND). R26 limits current.",
        "cathode GND. R26 330R. Q2/R25 DNP.",
    )
    src = src.replace(
        "Board: 70x55mm, 4-layer.",
        "Board: 52x60mm, 4-layer, V5 slim.",
    )
    src = src.replace(
        "J6-4 = 2nd LED3 (4-LED gauge).",
        "DS1-DS4 gauge, DS5 status, lid window.",
    )

    insertion = "\n" + "".join(parts) + "\n)\n"
    # Append before the final closing paren of kicad_sch
    if not src.rstrip().endswith(")"):
        raise RuntimeError("schematic does not end with )")
    # strip the last closing paren
    src = src.rstrip()
    assert src.endswith(")")
    src = src[:-1] + insertion

    SCH.write_text(src)
    print("Wrote", SCH, "size", SCH.stat().st_size)


if __name__ == "__main__":
    main()
