# DriveTrack PCB V4 — 原理图与 PCB 差异说明（SCHEMATIC-DELTA）

> **2026-11-12 更新：原理图已同步到 V4.4。** 新原理图为
> `drivetrack-pcb-v4.4.kicad_sch`（rev 4.4），与 V4.4 板文件
> `drivetrack-pcb-v4.4.kicad_pcb` 一致（KiCad 原生网表核对：
> 89 个原理图网络 vs 88 个板网络，仅剩 ANT1 pin 2 已知残留，见 §6；
> V4.4 唯一原理图改动是 D_SEL 断开 GND，见 §7）。
> 旧 v2 原理图 `drivetrack-pcb-v4.kicad_sch` 与 V4.2/V4.3 原理图
> 留存备查，不再改动。
> 以下 §1–§4 为 V4 的原始增量记录（已全部进新原理图）；
> §5 为 V4.1/V4.2 的增量记录；§7 为 V4.4 的增量记录。

## 1. 新增：电量分压 R30 / R31（VBAT_DIV）

| 位号 | 值 | 封装 | 连接 |
|------|-----|------|------|
| R30 | 100k | Resistor_SMD:R_0805_2012Metric | pin 1 → BAT，pin 2 → VBAT_DIV |
| R31 | 100k | Resistor_SMD:R_0805_2012Metric | pin 1 → VBAT_DIV，pin 2 → GND |

- 新增网络 **VBAT_DIV**：节点 R30:2、R31:1、U1:39。
- U1:39（ESP32 IO1）原在网表里是悬空网络 `unconnected-(U1-IO1-Pad39)`，
  V4 已删除该空网络，U1:39 改接到 VBAT_DIV。
- BAT 网络新增节点 R30:1；GND 网络新增节点 R31:2。
- 原理图里画法（建议位置：TP4/TP2 附近，电源区右侧）：
  - 从 BAT 标号（TP4 附近，坐标约 (341.84, 206)）引线到 R30 pin 1；
  - R30 pin 2 与 R31 pin 1 相连，中间加全局标号 `VBAT_DIV`；
  - R31 pin 2 接 GND 标号（TP2 附近，坐标约 (341.84, 170)）；
  - 再从 `VBAT_DIV` 标号引一根线到 U1 的 IO1（pin 39）脚。
  - R30、R31 的 Value 写 `100k`，Footprint 写
    `Resistor_SMD:R_0805_2012Metric`。
- 分压比 1/2：VBAT_DIV = BAT / 2。BAT 满电 4.2V 时 IO1 得 2.1V。
  固件 ADC 读数须按 2 倍换算回电池电压（固件另有人做）。

## 2. J4（U.FL）信号焊盘改独立网 GPS_UFL_DNI

- J4 pin 1 原在 GPS_RF 网络上；V4 改到新网络 **GPS_UFL_DNI**
  （仅 J4:1 一个节点）。
- GPS_RF 网络现只有 R8:2、U2:11 两个节点。
- 原理图里画法：把 J4 pin 1 从 GPS_RF 标号上断开，改挂一个
  本地标号 `GPS_UFL_DNI`（不接任何其他器件）。
- 注意：J4 是 DNI（不贴装），仅作 2.4G/GPS 备用测试口。
  以后若要启用 J4，需要飞线或加 0Ω，不能直接在现有微带上拉长分叉
  （会在 50Ω 路径上形成长支节）。

## 3. 其余与原理图一致（无差异）

- GPS 馈线 0.30mm → 0.35mm（R8 → U2 RF_IN 段）只是线宽改动，
  不涉及原理图。
- 4 个安装孔（MH1–MH4）是纯机械孔，不在原理图里。
- GPS_PPS 走底层、In1/In2 贴片 keepout、IP5306 假负载 DNI，
  均不涉及原理图。
- Q1/R19/R20/R21（IP5306 假负载）保持 DNI，与原理图一致。

## 4. 网表核对清单（V4 网表 vs 本文件）

- 器件数：84（v2/v3 为 82，+R30、R31）。
- 网络数：87（v2/v3 为 86：删 1 个悬空网络，加 GPS_UFL_DNI、VBAT_DIV）。
- BAT：C18:2、J3:1、J9:1、R4:1、TP4:1、R30:1。
- GND：…（69 个原节点）…、R31:2。
- GPS_RF：R8:2、U2:11。
- GPS_UFL_DNI：J4:1。
- VBAT_DIV：R30:2、R31:1、U1:39。
- 已删网络：`unconnected-(U1-IO1-Pad39)`（不应再出现）。

## 5. V4.1 / V4.2 增量（已进 V4.2 原理图，2026-11-12）

### V4.1：测试点 TP5–TP8
| 位号 | 值 | 封装 | 连接 |
|------|-----|------|------|
| TP5 | TP VBAT_DIV | PinHeader_1x01_Vertical | VBAT_DIV |
| TP6 | TP UART0_TX | PinHeader_1x01_Vertical | UART0_TX |
| TP7 | TP UART0_RX | PinHeader_1x01_Vertical | UART0_RX |
| TP8 | TP IO2 | PinHeader_1x01_Vertical | IO2 |

- TP5–TP8 在原理图里排在 TP1–TP4 同一列（x=352），TP8 在 y=296
  （y=278 让位给 Q2/R26 的 STAT_LED 走线）。
- UART0_TX / UART0_RX 网络各新增 TP6 / TP7 一个节点；
  VBAT_DIV 新增 TP5；IO2 新增 TP8。

### V4.2：LED4 独立驱动（R32、IO2 改角色）
| 位号 | 值 | 封装 | 连接 |
|------|-----|------|------|
| R32 | 330R | Resistor_SMD:R_0805_2012Metric | pin 1 → LED4，pin 2 → IO2 |

- J6 pin 4 从 LED3 断开，改接新网 **LED4**（仅 J6:4、R32:1 两个节点）。
- U1 pin 38（IO2）从 no-connect 改接 IO2 网；U1 pin 39（IO1）从
  no-connect 改接 VBAT_DIV 网（与 §1 的 R30/R31 分压对应）。
- IO2 不再是备用 GPIO，改作 LED4 驱动脚（HIGH=亮，LOW=灭）；
  TP8 仍为该脚测试点。板上此后无备用 GPIO。
- J6 pin 3 仍为 LED3（U5 pin 4）；LED3 网络为 U5:4、J6:3。

## 6. 已知残留（不改板，ERC 能过）

- **ANT1 pin 2（GND）无板焊盘**：原理图符号有 2 脚（FEED+GND），
  板上 ANT1 只有一个焊盘（pad 1，FEED）；贴片地靠接地平面。
  v2 遗留，原理图里该脚挂 GND 标号、板上无对应焊盘。
  KiCad 原生网表核对时 GND 会多出 ANT1:2 一个节点，
  其余 87 个网络全对。留作已知残留，不改板、不改原理图。

## 7. V4.4 增量（已进 V4.4 原理图，2026-11-12）

### V4.4：U2 D_SEL 断开 GND（致命错修复，唯一原理图改动）

- **问题**：U2（NEO-M9N）pin 2（D_SEL）在原理图里接 GND 标号，
  板上焊盘也连 GND。按 u-blox NEO-M9N Data Sheet UBX-19014285 R02，
  D_SEL=GND 时模组以 SPI 从机启动，UART 被禁用；板上 GPS 唯一数据
  通道是 UART（U2 pin 20/21 → ESP32），所以 V3 板的 GPS 数据通道
  是死的（只能收 PPS，拿不到定位）。原理图第 8681 行注释
  `"D_SEL=GND: UART mode"` 本身就是设计时的误判，与手册相反。
- **修法**：删 D_SEL 到 GND 的两条线（(220.22,48.22)→(215.14,48.22)
  与 (215.14,48.22)→(208,48.22)）与 power:GND 符号 #PWR014，
  在脚尖 (220.22,48.22) 加 no-connect 标记；D_SEL 悬空，
  靠模组内置 30–130kΩ 上拉 → UART+I2C（手册默认模式）。
  注释改为 `"V_BCKP tied to GPS_VCC (no backup battery). D_SEL open:
  UART+I2C (internal pull-up; GND would select SPI and disable UART)."`。
- **板同步**：U2 pad 2 的 net 改为 0（无 net），铺铜自动让出 0.2mm
  间隙；pad 20/21 仍为 GPS_RX/GPS_TX。
- **网表核对**：重导网表后 U2 pin 2 在 `unconnected-(U2-D_SEL-Pad2)`，
  GND 网的 U2 脚只剩 10/12/13/24/7；D_SEL 的 GND mismatch 已消失。
  原理图网络 89 个、板网络 88 个，唯一 mismatch 仍是 §6 的 ANT1 pin 2。
- **V3 板影响**：在产 V3 板 D_SEL 同样接 GND，GPS 数据通道已死。
  V3 返工须热风拆下 U2、隔离 pad 2（刮断热焊盘 spokes/贴 Kapton/
  补阻焊，万用表验隔离）再重贴；或接受 V3 板 GPS 无数据
  （仅作电源/RF/PPS 调通板）。详见 AUDIT-v4.4.md。

### V4.4 其余改动均不涉及原理图（只改封装与走线）

- U4（BMP390）封装 Y 取反、U3（BMI088）底排 X +0.30mm：
  仅焊盘坐标改动，网表不变（原理图/网络表本来就是对的）。
- U7/L1/ANT1 焊盘尺寸改动（ANT1 Ø3.0→Ø2.20、钻 Ø1.2→Ø1.00；
  U7/L1 放大后回退到官方库原值）：仅封装改动，网表不变。
- BOOT 过孔移位 (60.915,28.26)→(58.5,28.26)：仅走线改动。
- R30/R31/R32 的 R_0805 封装改回标准电阻版：仅封装改动。
- 盲孔 (35.1,23.85) F.Cu→In1.Cu **已删**，改放直通过孔 Ø0.5/钻 0.3
  （用户定改走线；BARO_SDA 的 In2.Cu 对角线改道让路）；GND 孤岛过孔、
  B.Cu GND 缝合线：仅走线/过孔改动，网表不变。

## 8. V4.4 修订收尾增量（用户定夺 5 项，2026-11-12）

### V4.4：J1 文字改 Push-Push（自弹式，用户 20:21 直接定）

- **改动**：J1 符号 Value 由 "microSD push-pull" 改为
  "microSD push-push"；说明文字由 "Push-pull (friction) socket,
  NO spring eject." 改为 "Push-push (spring eject) socket."。
  型号 DM3AT-SF-PEJM5 不变，封装不动，网表不变。
- **原因**：用户直接定 microSD 卡座为自弹式；DM3AT 本身就是 Push-Push，
  原文字写错了。BOM/原理图/板子/PnP 四处已统一为 Push-Push。
  弹卡行程 21.55mm，卡落在盒内须开盖取卡，与 v6.3 外壳（无卡槽开口）一致。
- **其余四项均不涉及原理图**：盲孔改走线与板孔扩孔只改板子与走线；
  L1 定型号只改 BOM；V3 板不贴片不涉及设计文件。详见 AUDIT-v4.4.md §H。
