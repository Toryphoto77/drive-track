# V4 PCB — 状态与后续路径（2026-11-12，V4.4 修订收尾完成）

## 当前状态：V4.4 修订收尾完成，DRC 0 errors，5 项用户定夺全部已执行

V4.4（2026-11-12 晚）：修掉嘉立创拦下的 U4 镜像与 U3 偏移两个致命错，
复核中又发现 U2 D_SEL 接 GND 致命错（V3 板 GPS 数据通道已死）并已修；
全部贴片元器件按型号查数据手册逐一核对（AUDIT-v4.4.md）；
DRC 0 errors、131 warnings；Gerber/BOM/PnP/阻抗说明已更新到 V4.4。
**用户定夺 5 项全部已定并执行**（见 AUDIT-v4.4.md §H）：① 盲孔改走线
（已除盲孔，改直通过孔 + BARO_SDA 改道）；② J1 定为自弹式 DM3AT-SF-PEJM5
（文字四处统一为 Push-Push）；③ L1 定稿 Bourns SRP7028A-1R0M；
④ 板孔 MH1–MH4 扩到 Ø3.4（MH2 连带三根竖线西移已修）；⑤ V3 板不贴、
只寄光板（V4.4 无遗留已知问题）。**不要打包发用户**（主代理统一打包发）。
V4.4 文件：板 `drivetrack-pcb-v4.4.kicad_pcb`、原理图
`drivetrack-pcb-v4.4.kicad_sch`、同名 `.kicad_pro`、Gerber
`gerbers-v4.4/`、BOM `bom-v4.4.csv`、PnP `pick-and-place-v4.4.csv`、
DRC 报告 `drc-report-v4.4.txt`、阻抗 `impedance-info-v44.txt` + PNG、
复核清单 `AUDIT-v4.4.md`。

## V4.4 改动摘要（详见 README-v4.txt §零·V4.4 与 AUDIT-v4.4.md）

1. U4 BMP390 封装 Y 取反（Pin 1 归位）；U3 BMI088 底排 X +0.30mm。
2. U2 D_SEL 断开 GND（原理图 + 板），悬空靠内置上拉 → UART+I2C。
3. 盲孔已除：原盲孔 (35.1,23.85) F.Cu→In1.Cu 已删，改放直通过孔
   Ø0.5/钻 0.3；BARO_SDA 的 In1.Cu 对角线改道（y=24.7 横段 +
   x=36.0 竖段）；U4 GND 孤岛过孔 + BOOT 过孔移位 + ANT1 焊盘
   Ø2.20/钻 Ø1.00。
4. U7/L1 焊盘放大后回退到官方库原值；R_0805 改回标准电阻版。
5. BOM：U4→C5124834、U6 "1A"→"3A"、SW1/SW2→PTS645SL43SMTR92LFS、
   J1→microSD push-push（自弹式 DM3AT-SF-PEJM5）、L1→SRP7028A-1R0M。
6. 钻孔 PTH 212（208 圆孔 + 4 处 J2 槽孔；直通孔 170、盲孔 0）/
   NPTH 6；板孔 MH1–MH4 扩到 Ø3.4；外壳 v6.3 验证 62 PASS、0 FAIL。

---

# V4 PCB — 状态与后续路径（2026-11-11，子代理工作记录）

## 当前状态：设计已完成，布线未收敛 — DRC 14 errors，未交付 Gerber

V4 的全部设计工作已完成并验证，唯一未完成的是布线收敛（DRC 归零）。
**Gerber 与 pick-and-place 尚未导出**（板子有 14 个未连项，导出即为断线板，不可交付）。
**drc-report-v4.txt 尚未生成**（须等 DRC 0 错误后）。

## 已完成并验证的工作

1. **网表 drivetrack-pcb.netlist**（84 器件 / 87 网络，已验证）：
   - 新增 R30、R31（100k，0805）；BAT 加 R30:1；GND 加 R31:2。
   - 新增 VBAT_DIV（code 88：R30:2、R31:1、U1:39）。
   - GPS_RF 删 J4:1；新增 GPS_UFL_DNI（code 87：J4:1）。
   - 删除已空的 unconnected-(U1-IO1-Pad39)。
2. **build_pcb.py**（V4 改动全部落脚本，可复现）：
   - PLACE 加 R30 (57.0,25.4,0)、R31 (61.0,25.4,0)（4.0mm 间距，0805 courtyard 不重叠）。
   - MOUNTING_HOLES 改为 V3 四孔 [(2.45,2.45),(68,21.7),(3.2,43.2),(64.2,52.95)]，Ø3.2 NPTH。
   - R8→U2 馈线 0.30mm 改 0.35mm。
   - GPS_PPS 预布（B.Cu 绕开贴片禁区；TP3 分支改走南侧 y=36.5 绕开 J4 封装内嵌 keepout，见下）。
   - patch keepout 加 In2.Cu（三层）。
   - Freerouting passes 20→60。
3. **MountingHole 封装 courtyard 已删**（DriveTrack.pretty/MountingHole_3.2mm.kicad_mod），否则 DRC 报 courtyard 重叠。
4. **bom-v4.csv**（52 行，V3 BOM + R30/R31，JLCPCB 基础库 100k 0805）。
5. **README-v4.txt**（改动清单、与 V3 差异、JLCPCB 下单注意：MH2 0.40mm / MH4 0.45mm V 割边沿用“接受”）。
6. **SCHEMATIC-DELTA-v4.md**（R30/R31 接法、VBAT_DIV 分压比 1/2、J4 改 GPS_UFL_DNI、网表核对清单）。
7. **export_gerbers.py**（已写，未跑：导 Gerber + 钻孔 + pick-and-place-v4.csv，层名与 V3 一致）。
8. **clearance_check.py**（已验证可用的间隙检查工具：check_track / check_via，0.2mm  clearance）。
9. **drc-report.txt**（当前为第二轮 60 passes 构建的 DRC 报告：14 errors / 123 warnings）。

## 关键发现（已实测）

### J4 封装内嵌 keepout（已修好）
J4（U.FL）封装在所有铜层都嵌了一个 keepout（x 26.98–29.07、y 34.05–35.95）。
V3 的 TP3 直线（y=34.5）穿过它；KiCad 9 未报，KiCad 7 报 items_not_allowed。
修法：TP3 分支改走南侧 B.Cu (30,34.5)→(30,36.5)→(6.8,36.5)→(6.8,34.5)。已落脚本，items_not_allowed 已归零。

### +3V3 未连的根因（zone 重叠）
In2 上 +5V 区 (10,42)-(42,54) 优先级 2，高于 +3V3 南区 (0,29.5)-(43,55) 优先级 1，
把 +3V3 南区在该范围挖空。+3V3 过孔 (28.644,45.688)、(31.744,45.615)、(41.061,47.736)
落在 +5V 区内，In2 上不接 +3V3。须用 F.Cu/B.Cu 走线把它们连到 +3V3 已连部分。

### MH2 与东侧走线高速冲突（V4 从头重布失败的根本原因）
v2 参考板在东侧 x≈66.8–67.7 有三条南北向走线（UART0_TX x=67.71、UART0_RX x=66.88、
SD_MOSI x=66.83），正穿过 V3 的 MH2 孔位 (68,21.7)（孔半径 1.6mm）。
Freerouting 从头重布时无法在新增约束（4 孔 + In2 keepout + GPS_PPS 预布）下收敛：
20 passes 剩 19 未连，60 passes 剩 14 未连，日志明确提示已收敛、再加 passes 无改善。

### V3 Gerber 实测：朋友的解法
V3 把东侧三条线西移到 x≈65.175 与 x≈66.0 绕开 MH2（F.Cu 有 (65.175,24.0)→(65.175,19.675)
竖线与 (66.0,19.9)→(66.0,24.425) 竖线；In1/In2 有 (66.0,19.0)→(66.0,23.8) 等绕行）。
即：**朋友是在 v2 已布通的板子上手术式改动，不是重布。V4 也必须走这条路。**

### 手动补线第一次尝试（已失败并完整回退）
/tmp/manual_route.py（已存为 manual_route_attempt1.py）加 38 个 track/via（In1 长折线 + F.Cu stub），
未连 14→1，但新增 81 clearance + 44 hole_clearance，总错误 14→133。
根因：过孔/走线凭目测放位撞既有铜皮；加线后未及时 refill zones。
已用 revert_manual2.py 完整回退 38/38 项并 refill，DRC 回到 14 errors / 123 warnings 的干净状态。
教训：手动布线必须先用 clearance_check.py 逐项验证，不能凭目测；不要用 In1 长折线横穿既有走线。

## 14 个未连项清单（第二轮 DRC，2026-11-11 约 13:00）
1. +3V3：F.Cu (28.64,43.35) vs Via (31.74,45.61)
2. +3V3：F.Cu (31.74,45.61) vs Via (33.36,41.74)
3. +3V3：F.Cu (40.325,47.0) vs F.Cu (39.105,41.5)
4. BARO_SCL：R12 pad 1 (22.675,30.6) vs In1 track (8.614,32.235)
5. GND：C2 pad 1 (42.05,8.0) vs Via (43.53,10.12)
6. GND：F.Cu (60.75,47.04) vs R18 pad 2 (63.325,50.5)
7. GND：F.Cu GND zone vs F.Cu GND zone @ (2.0,0.0)——F.Cu GND zone 被分割成孤岛
8. Net-(C24-Pad2)：R27 pad 1 (37.375,43.48) vs C24 pad 2 (41.78,45.26)
9. Net-(J2-SHIELD)：J2 PTH S1 (59.49,52.61) vs R18 pad 1 (61.675,50.5)
10. Net-(J2-SHIELD)：R18 pad 1 (61.675,50.5) vs J2 PTH S1 (59.13,46.66)
11. Net-(J2-SHIELD)：J2 PTH S1 (50.87,46.66) vs J2 PTH S1 (50.51,52.61)
12. Net-(J2-SHIELD)：J2 PTH S1 (59.13,46.66) vs J2 PTH S1 (50.87,46.66)
13. Net-(U6-VBST)：C23 pad 1 (34.415,43.5) vs U6 pad 6 (36.5975,48.63)
14. USB_CC1：R16 pad 2 (51.495,43.15) vs J2 pad A5 (54.25,44.75)

其中 +3V3 的 A→B (28.64,45.69)→(31.74,45.61) 与 C→E (33.36,41.74)→(38.01,41.42)
已用 clearance_check.py 验证在 B.Cu 上是干净的（可直接加）；B→C 与 E→D 在 B.Cu/F.Cu
直连均被 Q1-G、SD_CD、VBUS 挡住，须另找路径。

## 后续路径（按推荐顺序）

**路径 A（推荐）：以 v2 参考板为底做手术式修改**（朋友做 V3 的方法）
1. 复制 drivetrack-pcb-v2-reference.kicad_pcb（0 未连）为新底板。
2. 加 R30/R31 封装 + VBAT_DIV 网络（网表已有），只让 Freerouting 布 VBAT_DIV 这一条新网。
3. GPS 馈线 R8→U2 改 0.35mm（只改线宽）。
4. 删 GPS_RF 到 J4 的线段；J4 改 GPS_UFL_DNI。
5. 删 v2 的 2 个安装孔，加 V3 的 4 个孔。
6. 按 V3 Gerber 几何把东侧三条线（UART0_TX、UART0_RX、SD_MOSI）西移到 x≈65.175 / x≈66.0
   绕开 MH2（删旧线、按 V3 走法重布该段）。
7. 删 v2 In2 的 GPS_PPS 线，加 V4 B.Cu GPS_PPS 预布（TP3 走南侧 y=36.5）。
8. 加 In2 patch keepout；删 keepout 下残留的 In2 走线。
9. 逐项跑 DRC 验证，归零后跑 export_gerbers.py、核对 Gerber、生成 drc-report-v4.txt。
10. **注意**：此路径的板子与 build_pcb.py 从头构建的结果不一致——须把手术步骤写进
    一份 V4-MANUAL-STEPS.md，并更新 build_pcb.py 的注释说明（脚本为可复现的底，
    手术步骤为收尾，类比 V3 的做法）。

**路径 B：继续在当前 script+Freerouting 板子上手动补线**
用 clearance_check.py 逐项验证、逐 net 加、逐 net 跑 DRC。
已验证可行的先做（+3V3 A→B、 C→E 在 B.Cu 上）。
但 14 项全部手动收尾工作量大、且 B→C、E→D、USB_CC1、U6-VBST 等在 F.Cu/B.Cu
直连均被挡，须多层跳线，风险高。不推荐作为首选。

## 对照数据
- v2 参考板 DRC：0 未连，14 errors（8 clearance 0.16–0.19mm，6 copper_edge_clearance），199 warnings。
- V3 DRC（KiCad 9.0.2）：0 error，0 未连，140 警告。
- V4 当前（60 passes）：14 errors（全是未连），123 warnings，0 clearance 错误。
- V3 Gerber 在 /tmp/v3g/（F.Cu/In1/In2/B.Cu 等）；Gerber Y = -KiCad Y（解析时注意取反）。

---

# V4.1 完成（2026-11-12，固定孔精细化 + 调试/外设冗余）

## 最终状态：DRC 0 errors，ERC 0 errors，Gerber 已导出，可交付

- DRC（KiCad 7.0.11）：**0 errors**（见 drc-report-v4.txt）。129 个警告全为丝印重叠/压铜
  （与 V3 同类）与封装库不一致（预期内）及 2 个 via_dangling 警告（非错误）。
- ERC：板级 Python 等效检查 **0 错误**。VBAT_DIV 4 脚、GPS_UFL_DNI 有意单脚（DNI）、
  IO2 2 脚、无非有意单脚网、25 个 unconnected-* 均为有意空脚。
  注：原理图未同步 V4/V4.1 增量（R30/R31、VBAT_DIV、TP5–8 为 PCB 级添加）。
- Gerber：11 层 + 钻孔 PTH/NPTH（206 孔），见 `gerbers/`。
- Pick-and-place：`pick-and-place-v4.csv`，92 行（92 个封装）。
- 板文件：`drivetrack-pcb-v4.kicad_pcb`，92 个封装 / 88 个网络 / 206 钻孔。

## V4.1 改动总览（as-built，详见 README-v4.txt 与 V4-MANUAL-STEPS.md）

1. **R1 (66.0,24.0)→(67.0,26.0)**，离 MH2 孔心 3.57mm；BOOT 改走 B.Cu 下穿 SD_MOSI。
   **R18 (62.5,50.5)→(62.5,45.0)**，离 MH4 孔心 7.22mm；J2-SHIELD 改走 B.Cu 下穿 USB_CC2。
   MH1 接受小头 M3（头 Ø5.0）；MH2/MH4 的 V 割边距 0.40/0.45mm 沿用“接受”。
2. **Ø7mm 元件禁布区**：未做 DRC 强制 keepout（4 个孔的 Ø7 圈全撞既有不可动元件，
   强制会留 4 个无法消除的 DRC 错误），改为 Cmts.User 层 Ø7 可视圆 + README 书面规则。
   In2 贴片 keepout (4.2,4.2)–(29.8,29.8) 只禁走线/过孔，已保留。
3. **测试点**：TP5=VBAT_DIV (32.8,3.5)、TP6=UART0_TX (36.6,3.5)、TP7=UART0_RX (40.4,3.5)
   排北带；TP8=IO2 (34.0,9.5) 走廊。全部已布线，DRC 未连归零。
4. **备用 GPIO 仅 IO2 一路**（TP8）。IO3 因南边拥塞无法引出（U1:15 保持未连）；
   IO41 也不可布；J10 1x04 排针方案已放弃（走廊撞 IMU 竖线与 C10，板边无 4 点位）。
5. **安装核对**：USB J2 与 v5 开孔 Y=25.00 精确对位；J8/J6/J7 为线束接线座
   （M16 按键与 LED 面板安装）；J3 电池座、J1 SD 卡内置、透气孔 X=41 对 BMP390。
   外壳坐标换算：enc_X = PCB_y + 11，enc_Y = 80 − PCB_x。
6. **v2 固有 8 clearance 已修**（5 颗过孔微调 0.03mm 步长，连带走线端点同移）；
   板设铜边距改 0.25mm（6 个 copper_edge_clearance 归零）；删 1 颗孤 GND via。
7. **export_gerbers.py 已修 4 处 KiCad 7.0.11 API 差异**（SetPlotDir / SetPlotViaOnMask /
   SetPlotPadsOnSilkLayer / SetPlotMirror / PlotOptions.NO_DRILL_SHAPE /
   EXCELLON_WRITER.SetOptions 关键字参数），现可正常导出。

## 与 V3 的差异（V4.1 交付须知）

- 阻焊颜色：V3 订单已定为蓝色（用户 2026-11-11 确认“就是蓝色”，哑黑作废）。
  V4.1 下单用蓝色，与 V3 一致。README-v4.txt 旧版“哑黑”已修正。
- V3 在产板装 v5 外壳暂定（仅限 V3 在产板——V3 板已生产、改不了，点胶是 V3 的临时办法）：
  MH3 标准 M3 + MH1 小头 M3（头 Ø5.0）+ MH2/MH4 点胶（V3 板 R1/R18 未挪，标准盘头会压到）。
  V4.3 板四个孔一律上螺丝、不打胶（2026-11-12 移孔改版已解决，
  见本文末“V4.3 完成”一节与 README §六）：MH1 小头 M3、MH2 小头 M3、
  MH3 标准 M3、MH4 标准 M3。V4.1/V4.2 板 MH2、MH4 仍不能可靠安装
  （MH2 撞 U1 模组、MH4 撞 J5），已由 V4.3 取代。
- 原理图未同步 V4/V4.1 增量；网表文件 drivetrack-pcb.netlist 为手术前版本，
  V4.1 增量（TP5–8、IO2）未进网表文件，以板文件为准。

## 未解决的风险（交付时须说明）

1. **V3 板的 LED4 镜像问题——V4.2 已解决**（用户 2026-11-12 01:38 定方案 A）。
   V4.2 把 J6 pin 4 从 LED3 断开改接 LED4（IO2 经 R32 330R 直驱），
   4 档电量显示真正独立。V3 在产板与 V4.1 板仍有此问题（J6 pin 4 并 LED3），
   不返工；V4.2 板解决。固件须配合（IO2 驱动 LED4，见下第 7 条）。
2. **备用 GPIO 已无**。V4.1 时仅 IO2 一路备用；V4.2 起 IO2 改作 LED4 驱动脚，
   板上无备用 GPIO（IO3/IO41 仍不可引出）。若后期需更多外设引脚，须另做一版
   （板边无空位，须挪元件）。
3. **原理图未同步 V4/V4.1/V4.2 增量——已解决（2026-11-12）**。
   新原理图 `drivetrack-pcb-v4.2.kicad_sch`（rev 4.2）已与 V4.2 板文件
   同步：R30/R31、VBAT_DIV、TP5–8、IO2、LED4、R32 全部进原理图；
   KiCad 原生网表核对 88 个网络全对，仅剩 ANT1 pin 2 已知残留
   （原理图 GND 脚无板焊盘，v2 遗留，不改）。详见本文末“V4.2 原理图同步”一节。
4. **丝印警告 213 个**（重叠/压铜，与 V4.1 同类）。不影响生产与 DRC 0，但丝印
   可读性与 V4.1 同水平，未优化。
5. **V3 板到货实测仍待做**（用户验板、补焊、烧固件、上电测、装壳；LED4 决定一并处理）。
6. **固件 ADC 读数**：VBAT_DIV 硬件已就绪（分压 1/2 到 IO1），固件须按 2 倍换算
   回电池电压（另派工，不在本任务内）。
7. **固件 IO2 驱动 LED4**（V4.2 新增，另派工）：IO2 设为输出；电量 ≥75% 时拉高
   点亮 LED4（75–100% 档），低于 75% 拉低熄灭。IO2 HIGH=亮，LOW=灭。
   四档：LED1 <25%、LED2 25–50%、LED3 50–75%、LED4 75–100%（按 ADC 电量阈值）。
8. **MH2、MH4 螺丝头 clearance 不足——V4.3 已解决（2026-11-12，见本文末“V4.3 完成”）**。
   V4.2 实测（板文件量出）：MH1 小头 M3 可用（ANT1 角 2.83mm，余量 0.33mm）、MH3 标准 M3 可用
   （J3 体 3.47mm，余量 0.72mm）；MH2 标准/小头 M3 均不行——U1 模组体 2.28mm（标准头压进 0.47mm、
   小头压进 0.22mm），另有 SD_MOSI（F.Cu）1.88mm、+3V3 过孔 2.10mm；MH4 标准 M3 不行——J5 体 2.53mm
   （标准头压进 0.22mm），小头 M3 仅余 0.03mm（不可靠），另有 GND 过孔 1.91mm 在头下。
   V4.1“四个孔均可用标准 M3”的结论是错的（只量了 R1/R18，没量 U1/J5、走线与过孔）。
   V4.3 按上述方案改板：MH2 南移至 (68,22.7) + SD_MOSI/+3V3 改走线，
   MH4 西移至 (63.7,52.95) + GND 过孔移至 (64.23,48.8)；V4.3 板实测
   MH1 小头（余量 +0.40mm）、MH2 小头（余量 +0.28mm，最近铜）、
   MH3 标准（余量 +0.66mm）、MH4 标准（余量 +0.23mm），四个孔全部
   上螺丝、不用胶。详见 README §六与 §零 V4.3。

---

# V4.2 完成（2026-11-12，LED 方案 A：GPIO 独立驱动第 4 颗电量灯）

## 最终状态：DRC 0 errors，ERC 0 errors，Gerber 已导出，可交付

- DRC（KiCad 7.0.11）：**0 errors / 213 warnings**（见 drc-report-v4.2.txt）。
  警告全为丝印重叠/压铜（与 V4.1 同类）与封装库不一致（预期内）及
  via_dangling 警告（非错误）。V4.1 同方法重跑为 0 errors / 212 warnings；
  V4.2 仅 +1 个警告（R32 丝印）。
- ERC：板级 Python 等效检查 **0 错误**。IO2 3 脚（U1:38、TP8、R32:2）、
  LED4 2 脚（J6:4、R32:1）、LED3 2 脚（U5:4、J6:3），无非有意单脚网。
  注：原理图未同步 V4/V4.1/V4.2 增量（R30/R31、VBAT_DIV、TP5–8、IO2、
  LED4、R32 为 PCB 级添加）。
- Gerber：11 层 + 钻孔 PTH/NPTH（209 孔 PTH），见 `gerbers-v4.2/`。
  V4.1 的 `gerbers/` 未动。
- Pick-and-place：`pick-and-place-v4.2.csv`，93 行（93 个封装，R32 在列）。
- 板文件：`drivetrack-pcb-v4.2.kicad_pcb`，93 个封装 / 89 个网络 / 209 钻孔 PTH。
  V4.1 的 `drivetrack-pcb-v4.kicad_pcb` 未动。

## V4.2 改动总览（as-built，详见 README-v4.txt §零）

1. **J6 pin 4 改接 LED4**：从 LED3（U5 pin 4）断开，改接新网 LED4。
   J6 引脚定义：1=LED1、2=LED2、3=LED3、4=LED4、5=GND。
   LED3 的 F.Cu 跳线 (45.12,53.1)→(42.58,53.1) 已删；J6 pin 3 仍走 B.Cu 接 LED3。
2. **R32 = 330Ω 0805（C_0805_2012Metric）**，中心 (33.0,35.0)，
   pad1 (32.05,35.0)→LED4，pad2 (33.95,35.0)→IO2。直驱，不加三极管。
   电流 (3.3V−2.0V)/330Ω ≈ 3.9mA，匹配 IP5306 的 4mA。
   IO2 HIGH = LED4 亮，LOW = 灭。
3. **R32 位置**：J6 附近顶面无 courtyard 空位（J2/J8/J7/R24 密集；
   y=49.5 处要躲 J2 须 x<47.87、要躲 J8 须 x>49.70，无解），
   故放在中北空位 (33.0,35.0)（courtyard 与 F.Cu 铜皮均干净）。
4. **IO2 布线**：TP8 (34.0,9.5) → R32 pad2 (33.95,35.0)，主走 B.Cu，
   过孔 (32.25,31.50)，F.Cu 短线接 R32 pad2。24 段 + 1 过孔。
5. **LED4 布线**：J6 pin 4 (45.12,53.1) → R32 pad1 (32.05,35.0)，
   主走 B.Cu，过孔 (45.85,45.00)→F.Cu 1.5mm→过孔 (45.75,43.50)→B.Cu，
   过孔 (32.00,35.25)→F.Cu 接 R32 pad1。21 段 + 3 过孔。
   其中 (45.85,45.00) 过孔为绕开 SD_CD 的 B.Cu 横线（y=44.16）而跳层；
   该过孔由 (45.75,45.00) 东移 0.1mm（原位距 R24 pad2 仅 0.185mm，
   要求 0.2mm），移后 DRC 归零。
6. **IO2 不再是“备用 GPIO”**，改作 LED4 驱动脚；TP8 仍为该脚测试点。
   板上此后无备用 GPIO。
7. **布线方法**：网格 A* 布线器（`astar_route.py`，四层 + 过孔，含全部
   通孔/焊盘/禁布/缺口；B.Cu 优先，避铺铜切分）+ `clearance_check.py`
   逐项验证。教训：① 检查器须含全部通孔（四层），只算单层会漏内层
   过孔致撞孔；② In1 长线会切分 GND 铺铜（首版 17 错误中 2 条 GND 未连
   即由此来），长线须走无铺铜的 B.Cu；③ A* 的过孔须按“过孔半径+间隙”
   （0.5mm）而非“线半宽+间隙”（0.35mm）留位，否则过孔距焊盘差 0.015mm。
   A* 路径呈阶梯状（0.25mm 网格 8 向），功能正确、外观欠整洁，
   已用 DRC 0 验证通过，不再手工整形。

## 与 V4.1 的差异（V4.2 交付须知）

- V4.1 的板文件、Gerber、BOM、PnP、DRC 报告一律未动；V4.2 全部存成
  新文件/新目录（`drivetrack-pcb-v4.2.kicad_pcb`、`gerbers-v4.2/`、
  `drc-report-v4.2.txt`、`bom-v4.2.csv`、`pick-and-place-v4.2.csv`）。
- 阻焊颜色：蓝色，与 V3/V4.1 一致。层叠、板厚、安装孔、GPS 贴片/U2/
  馈线、R1/R18、TP5–8 位置一律不动。
- 原理图未同步 V4/V4.1/V4.2 增量——2026-11-12 已解决（见文末）。
  网表文件 drivetrack-pcb.netlist 仍为手术前版本，以板文件为准；
  新原理图已用 KiCad 原生网表核对过板文件，无需依赖旧网表文件。
- 固件须配合：ADC 读 VBAT_DIV（IO1，×2 换算）；IO2 驱动 LED4
  （≥75% 拉高，<75% 拉低；HIGH=亮）。固件另派工，不在本任务内。

---

# V4.2 原理图同步 + 全文件交叉检查（2026-11-12）

## 最终状态：原理图已同步到 V4.2，ERC 0 错误，交叉检查全过

- 新原理图：`drivetrack-pcb-v4.2.kicad_sch`（rev 4.2，2026-11-12），
  v2 旧原理图 `drivetrack-pcb-v4.kicad_sch` 留存备查未动。
  同步脚本 `surgery_sch_v42.py`（S-expression 手术 + 序列化往返校验）。
- ERC 等效检查（Python 几何网表）：**0 错误**。21 个 no-connect 标记
  与 21 个空脚一一对应（另 4 脚 U2:15/16/17、U3:2 为库内 no_connect 型，
  无需标记）；无短路（同组双网名）、无重复位号、全部符号有库/封装/值、
  1091 个 UUID 无重复。
- 一致性（KiCad 原生网表 vs 板文件）：**88 个网络全对**，仅剩 ANT1 pin 2
  已知残留（原理图 GND 脚无板焊盘，贴片地靠接地平面，v2 遗留，不改）。
  Python 几何网表核对亦全对（除 J2 字母焊盘的脚本人工产物外）。
- KiCad 7.0.11 已装回本机（apt 重装主包），新原理图可原生读入
  （`kicad-cli sch export netlist` 通过）；新板文件可原生读入
  （pcbnew 连接性检查：89 个网络，仅 GPS_UFL_DNI 与 25 个
  unconnected-* 为有意单脚网，其余均正常连接）。
  注意：kicad-cli 7.0.11 没有 `pcb drc` 子命令，pcbnew Python 也无
  DRC_ENGINE，故 DRC 未能原生重跑；但本次板改动仅为 7 处文本
  （库名/丝印值），几何与网络未动，且 Gerber 重导出 11 层 0 行差异，
  故 DRC 仍为 0 errors（见 drc-report-v4.2.txt）。

## 本轮修掉的问题

1. **原理图同步**（新文件）：R30/R31 分压、R32（330R）、J6 pin 4 改 LED4、
   U1 pin 38→IO2、pin 39→VBAT_DIV、J4 pin 1 改 GPS_UFL_DNI、
   TP5–TP8 新增；J5–J9、TP1–TP4 封装 Horizontal→Vertical；
   U5 改 DriveTrack 定制封装、U7 补 _P1.75mm 后缀。
   TP8 放在 y=296（y=278 让位给 Q2/R26 的 STAT_LED 走线）；
   R30/R31 用 rot 180 使 pin 1 在上（与板文件脚号一致）。
2. **板文件文本**：R30/R31/R32 封装库 Capacitor_SMD→Resistor_SMD；
   TP5–TP8 的 fp_text 值 "TP +3V3" 改为正确值。
   仅 7 处字符串改动，几何/网络/焊盘全未动（93 封装/89 网络/865 走线/167 过孔不变）。
3. **BOM**：J5–J9、TP1–TP8 封装 Horizontal→Vertical；U5 改定制封装；
   U7 补 _P1.75mm；TP8 备注改掉 "Spare GPIO"（IO2 已是 LED4 驱动脚）；
   R30/R31 的 Ref 双引号 `""R30,R31""` 改为正常引用；另清掉同行 MPN/Notes
   的多余引号。BOM↔板：94 个位号全对（89 板内部件 + 5 板外 LED）。
4. **PnP**：TP5–TP8 的 Val 改为正确值；R30/R31/R32 的 Package
   C_0805→R_0805。PnP↔板：93 行全对（坐标/封装/值）。
5. **阻抗信息重写**（按 V4.2 板实测）：GPS 馈线为 ANT1-FEED 0.40mm
   + GPS_RF 0.35mm，全顶层、无过孔；旧版写 GPS_RF 0.25mm 走 In1.Cu
   是错的（那是 V3 的走法）。txt 与 PNG 均已重写，正式版同步到
   manufacturing/impedance-info.txt 与 manufacturing/impedance-trace-locations.png。
6. **钻孔数纠正**：V4.2 PTH 实为 209 孔（167 过孔 + 42 焊盘；钻孔文件
   205 圆孔 + 4 个 J2 槽孔），此前 README/STATUS 写 213 孔系误把
   4 个安装孔计入 PTH，已修正；V4.1 实为 205 孔（此前写 206，亦为误计）。
   J2 的 5 个槽孔在 V4.2 钻孔文件里为 route 格式（G00/M15/G01/M16），
   与 V3 的 G85 格式等效、坐标一致，已用 KiCad 重导出核对。
   Gerber 11 层重导出与现有 gerbers-v4.2/ 0 行差异，确认 Gerber 为最新。

---

# V4.3 完成（2026-11-12，四个安装孔全部上螺丝 + 气压计/安装空间核实）

## 最终状态：DRC 0 errors，ERC 等效 0 错误，Gerber 已导出，外壳 v6.1 已验证，可交付

- 板文件：`drivetrack-pcb-v4.3.kicad_pcb`（93 封装 / 89 网络 / 1034 走线 / 169 过孔）。
  原理图 `drivetrack-pcb-v4.3.kicad_sch`（rev 4.3；与 V4.2 同网表，仅标题栏 rev 改动）。
  工程文件 `drivetrack-pcb-v4.3.kicad_pro` 与板文件同名（V4.2 的教训：规则在
  .kicad_pro 里，文件名对不上 KiCad 会用默认规则跑出假阳性）。
- DRC（KiCad 7.0.11，原生 `pcbnew.WriteDRCReport`，`run_drc_v43.py`）：**0 errors / 133 warnings**
  （见 `drc-report-v4.3.txt`）。警告：丝印重叠 67、丝印压铜 55、库不一致 8、
  via_dangling 2、丝印边距 1。警告数由 V4.2 的 213 降至 133，是 DRC 环境
  的库解析差异（V4.2 那次 89 个 lib_footprint_issues 是标准库解析不到），
  板子本身丝印/via 警告与 V4.2 基本一致。
- ERC 等效检查（`check_erc_v43.py`：`kicad-cli sch export netlist` vs 板文件）：
  **0 错误**。88 个网络全对，仅剩 ANT1 pin 2 已知残留（v2 遗留，不改）；
  25 个 unconnected-* 均为有意空脚；GPS_UFL_DNI 有意单脚（DNI）。
- Gerber：`gerbers-v4.3/`（11 层 + PTH/NPTH 钻孔，`export_gerbers_v43.py`）。
  钻孔 PTH 实为 **211 孔**（169 过孔 + 42 焊盘；钻孔文件 207 圆孔 + 4 个 J2 槽孔），
  NPTH 6 孔不变（4×Ø3.2 安装孔 + J2 Ø0.65 圆孔 + 1 槽孔）。
- BOM `bom-v4.3.csv`（与 V4.2 相同，器件未变，57 行）、PnP
  `pick-and-place-v4.3.csv`（93 行，MH2/MH4 为新孔位）。

## 本轮改动

1. **MH2/MH4 移孔**：MH2 (68,21.7)→(68,22.7)，MH4 (64.2,52.95)→(63.7,52.95)；
   MH1/MH3 不动。手术脚本 `surgery_v43.py`。
2. **SD_MOSI/+3V3 改走线**（as-built，`verify_v43_asbuilt.py` 全过，FAILS: none）：
   SD_MOSI 经 (66.827,19.90) Ø0.50 过孔转 B.Cu、x=66 竖走至 y=28.0 再回 F.Cu；
   +3V3 过孔移至 (69.0,26.0)（边沿 69.30，未进东侧 keepout x≥69.5）；
   UART0_RX/TX 的 y=23.8 jog 南移至 y=25.0。B.Cu x=66 竖线离 MH2 孔边 0.275mm。
   旧验证脚本 `validate_v43_reroute.py` 是术前规划工具（验 V4.2 板上的拟改几何），
   其 4 个 FAIL 已过期，以 `verify_v43_asbuilt.py` 为准。
3. **GND 过孔移出 MH4 螺丝头 + 铺铜重填**（本次唯一的关键修复）：
   过孔 (64.2336,50.742)→(64.23,48.8)，离新 MH4 孔心 4.18mm（头下余量 +1.13mm）。
   移孔后未重填铺铜时，旧 +3V3 In2 铺铜盖住新孔位，GND 过孔与 +3V3 铺铜
   0.000mm 接触（DRC 1 clearance + 1 hole_clearance error）；用
   `refill_zones_v43.py`（`pcbnew.ZONE_FILLER` + `pcbnew.ZONES()` 容器，
   build_pcb.py 同款做法）重填 28 个 zone 后 DRC 归零。
   教训：凡动过孔/走线/孔位，必须重填铺铜再跑 DRC；`ZONE_FILLER.Fill`
   要传 `pcbnew.ZONES()` 容器（Python list 不会被 SWIG 接受），且须跳过
   rule area。另：§一.7“已删 1 颗孤 via”的说法是错的——该过孔在 V4.1/V4.2
   均存在（两版 DRC 报告皆有其 via_dangling 记录），README 已更正。
4. **螺丝头 clearance**（`verify_v43_precise.py`，courtyard/焊盘/走线精确量测）：
   MH1 小头 M3（ANT1 贴片角 2.90mm，余量 +0.40mm）、MH2 小头 M3（U1 模组角
   2.83mm，余量 +0.33mm；最近铜 SD_MOSI 过孔 2.78mm，余量 +0.28mm；标准 M3
   仅余 +0.03~+0.08mm，不用）、MH3 标准 M3（J3 体 3.41mm，余量 +0.66mm）、
   MH4 标准 M3（J5 体西沿 2.98mm，余量 +0.23mm）。四个孔全部上螺丝、不用胶。
   注意：U1/J5/ANT1 的 courtyard 角比本体近 0.6–0.7mm（MH2 courtyard 角 1.88mm、
   MH4 2.50mm、MH1 2.47mm），那是布局 keep-out，不是本体；螺丝头不碰本体，
   DRC 孔 clearance 亦通过。
5. **外壳 v6.1**（`~/workspace/drivetrack-enclosure-v6.1/`，v6 不动）：
   MH2 支柱 enc_x 32.70→33.70，MH4 支柱 enc_y 15.80→16.30；其余不动
   （透气孔未动，见下条）。构建 `enclosure_v6.1.py`（CadQuery 2.8.0，
   复用 v6 的 `.venv-cq`），验证 `verify_v6.1.py`：**60 PASS、0 FAIL**；
   四支柱与 V4.3 板四孔对位误差 0.00mm（换算 enc_x = 11 + pcb_y，
   enc_y = 80 − pcb_x）。
6. **气压计对透气孔**（用户 09:18 追加）：U4（BMP390，pcb 4.50,31.20）→
   外壳 enc_x 42.20，透气孔 X=41，偏差 1.20mm，在 Ø3 孔（39.5–42.5）与
   Ø10 膜（36–46）范围内；U4 顶 z≈19.35，透气孔 Z=20；气路经板北边
   7mm 空隙直达 U4，邻件 C9/C12/TP3 均 ≤0.5mm 高，无遮挡。**不改孔、不动 U4。**
7. **按钮 / LED 安装空间核实**（用户 09:18 追加，Onpow GQ16F 数据手册实测）：
   - M16 按钮：针端子版 GQ16F-10/J 本体 Φ11.8×17.5mm，底边 z=19.70，
     高出板顶（18.6）1.10mm；本体下方仅 TP5–TP8 焊盘；螺母座止于 x=9.80，
     离板边（x=11.0）1.20mm。**必须买针端子版（J）**——螺丝端子版本体
     23mm 会撞 SW2（RST 键，F.Fab 框 enc_x 24.95–31.05、enc_y 34.95–41.05）。
   - LED：J6 的 1–3 脚正处 5mm 状态灯座块下方（座块底 z=23.0），焊盘上
     线从座块下方 4.4mm 缝隙穿出；J8 的 1 脚贴着座块西沿（0.06mm 内），
     线朝西出。**J6/J7 不插竖排针的原因更正**：竖排针会撞 5mm 状态灯座块，
     不是撞 M16 按钮体（按钮体在 40mm 开外）——旧说法是错的，README §三已更正。
   - LED 线走 L1 西侧，勿压 L1 顶：L1 高 4.5mm（顶 z=23.1），灯座条底
     z=24.0，仅 0.9mm 缝；5mm 状态灯尾露出约 2.6mm，离 J7 仅 0.5–3mm。
   - 板边间隙：西 8.0mm、东 0mm（与腔壁贴合，系设计：USB 壳伸进壁孔）、
     北 7mm、南 7mm。装入须先斜插 USB 端进壁孔、再放平上螺丝。
- 固件须配合：无新增（V4.3 不改电路；LED4/ADC 仍按 V4.2 方案，另派工）。

## 残留问题

- **ANT1 pin 2（GND）无板焊盘**（v2 遗留，已知残留）：原理图符号有
  2 脚，板上 ANT1 只有一个焊盘（FEED），贴片地靠接地平面。
  KiCad 原生网表核对时 GND 多出 ANT1:2 一个节点，其余全对。
  不改板、不改原理图。
- **DRC 已原生重跑（V4.3）**：`pcbnew.WriteDRCReport` 原生跑出 0 errors
  （见 `drc-report-v4.3.txt`）。kicad-cli 7.0.11 仍无 `pcb drc` 子命令、
  pcbnew Python 仍无 DRC_ENGINE，DRC 须走 WriteDRCReport；ERC 仍用
  板级网表等效检查（原生 ERC 引擎未暴露）。
- **USB_DP/DM 长度差**：USB_DP 35.7mm、USB_DM 58.5mm（差 22.8mm），
  为既有布线（V3 即如此），全速 USB 可接受；未改动，仅记录。
- **V4.2 补充包未重打**：DriveTrack-PCB-V4.2-supplement.zip 未动，
  等用户确认后再重新打包（本次新增的 V4.2 原理图与修正后的阻抗图、
  BOM、PnP 届时一并进包）。
- **J6/J7 不插竖排针**（V4.3 核实）：J6 的 1–3 脚正处 5mm 状态灯座块
  下方（座块底 z=23.0），竖排针（顶约 z=27）会撞座块；J8 的 1 脚贴着
  座块西沿。线一律直接焊焊盘，从座块下方 4.4mm 缝隙穿出。
  旧说法“会撞 M16 按钮体”是错的（按钮体在 40mm 开外），README 已更正。
- **M16 按钮必须买针端子版（GQ16F-10/J）**：本体 Φ11.8×17.5mm；
  螺丝端子版本体 23mm 会撞 SW2（RST 键）。买前核对型号后缀带 J。
- **V4.3 补充包未打包**：V4.3 的板/Gerber/BOM/PnP/DRC/原理图已全部
  就绪，等主代理统一打包发用户（本次不单独发）。
